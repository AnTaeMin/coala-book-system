---
schema_version: 1
title: AI와 함께하는 바이브 코딩
subtitle: 원본 실습 중심 16차시 · 대조 수정판
learner_level: 코딩 입문자
language: ko
canvas: coala-portrait
numbering: auto
toc: none
assets_dir: ./assets
---

:::page{type="concept" id="book-guide" layout="basic"}
# 이 교재를 사용하는 방법

## 원본 실습을 따라 배우기

158쪽 원본 교재의 실습과 문제풀이 예시를 16차시로 재구성했습니다. 각 실습에 원본 PDF 쪽수와 실습 이름을 표시했습니다.

## 입력·동작·결과 확인

책의 조건과 위젯 이름을 먼저 읽습니다. 책에 제시된 값을 입력하고, 실행 결과를 원본 화면과 비교합니다. 입력값이 정해져 있지 않은 과제에서는 학습자가 값을 정합니다.

## 코드와 그림

원본 GUI 화면은 원본에서 추출했습니다. Matplotlib·Pandas 코드는 원본의 데이터와 동작을 유지하고 독립 실행에 필요한 생성 코드 및 오타만 보완했습니다.
:::

:::page{type="chapter-opening" id="ch01-opening" chapter="1"}
# AI와 함께하는 디지털 시대

## 1차시 · 원본 교재 예시로 배우기

### 학습 목표

- 생성형 AI의 역할과 한계를 설명할 수 있다.
- 사실 확인이 필요한 답변을 구분할 수 있다.
- AI에게 맡길 일과 내가 검증할 일을 정할 수 있다.

### 오늘의 시작

책은 AI가 잘하는 일과 어려워하는 일을 비교하는 활동으로 시작합니다. 바이브 코딩에서도 AI가 코드를 만들고, 사람은 목적과 동작을 확인합니다.
:::

:::page{type="concept" id="ch01-ai" layout="basic"}
# 생성형 AI와 바이브 코딩

## 생성형 AI란?

생성형 AI는 요청에 따라 글, 이미지, 코드 같은 결과물을 만듭니다. 추천 영상이나 번역 등 일상 속 AI와 연결해 생각해봅시다.

## 코드를 만드는 과정

바이브 코딩에서는 원하는 앱을 말로 설명하고 AI가 제안한 코드를 실행합니다. 결과를 직접 확인하고 수정 요청을 반복합니다. 사람이 입력·처리·출력을 설계하고 실행 결과를 확인하는 과정이 중요합니다.
:::

:::page{type="comparison" id="ch01-limits"}
# AI가 잘하는 일과 확인할 일

입력과 처리 결과를 나란히 비교해봅시다.

| 활용할 일 | 사람이 확인할 일 |
|---|---|
| 긴 정보 요약 | 빠진 내용과 왜곡 여부 |
| 아이디어 제안 | 목적에 맞는지 여부 |
| 반복 작업용 코드 작성 | 입력과 실제 실행 결과 |
| 새로운 정보 설명 | 날짜와 공식 근거 |
:::

:::page{type="concept" id="ch01-ethics" layout="basic"}
# AI의 답을 검토하는 태도

## 환각

AI가 사실과 다른 내용을 자신 있게 말하는 현상을 환각이라고 합니다. 자신 있는 말투는 정확성의 증거가 아닙니다.

## 책임 있는 사용

실제 개인정보 대신 가상 데이터를 사용합니다. 다른 사람의 자료를 사용할 때 출처와 이용 조건을 확인합니다. 생성 결과의 오류와 편향을 검토하고, 제출물에서 AI 도움을 받은 부분을 밝힙니다.
:::

:::page{type="practice-opening" id="ch01-practice-1" practice="001-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# AI는 어떤 질문을 잘하고, 어려워할까?

원본 PDF 8쪽 · 실습 001-1.

일반 지식, 실시간 정보 등 질문 유형에 따라 AI의 답변을 비교해봅시다. 답변을 잘한 질문과 확인이 필요한 질문을 구분합니다. 개인 정보는 실제 개인정보를 입력하지 않고 질문 유형으로만 살펴봅니다.

> [!TIP]
> 원본 활동처럼 질문 유형에 따른 차이를 살펴봅니다.

- [ ] 서로 다른 질문 유형을 비교했다.
- [ ] 잘 답한 부분과 확인할 부분을 구분했다.
- [ ] AI 답변의 근거를 확인했다.
:::

:::page{type="step-process" id="ch01-procedure"}
# 답변의 근거 찾아보기

## 질문 두 개 정하기

정의나 요약을 묻는 질문과 날짜에 따라 바뀌는 정보를 묻는 질문을 구분합니다.

## 확인할 문장 고르기

답변에서 사실로 제시된 문장 하나를 골라 원문, 공식 안내 또는 교사가 제시한 자료와 비교합니다.

## 활용 여부 결정하기

맞는 내용, 틀린 내용, 확인하지 못한 내용을 나누어 기록합니다.
:::

:::page{type="practice-checklist" id="ch01-check"}
# 원본 실습의 완료 확인

- [ ] 원본 실습의 질문 유형을 비교했다.
- [ ] 잘 답한 질문과 확인할 질문을 구분했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch02-opening" chapter="2"}
# 좋은 질문이 좋은 답을 만든다

## 2차시 · 원본 교재 예시로 배우기

### 학습 목표

- 프롬프트의 의미를 설명할 수 있다.
- 목적, 대상, 상황, 조건을 담아 요청할 수 있다.
- 앱의 목적에 맞는 입력 데이터를 정할 수 있다.

### 오늘의 시작

같은 AI라도 요청에 담긴 조건에 따라 결과가 달라집니다. 책의 공부 계획과 여행 질문을 앱 제작 요청으로 연결합니다.
:::

:::page{type="concept" id="ch02-prompt" layout="basic"}
# 프롬프트의 구성

## 프롬프트란?

프롬프트는 AI에게 전달하는 질문, 요청, 지시문입니다. 무엇을 만들지, 누구를 위한 것인지, 어떤 조건을 지켜야 하는지 적습니다.

## 책의 공부 계획 예시

공부 계획 알려줘보다 시험이 2주 남았고 하루 2시간 공부할 수 있다는 상황을 함께 알려주면 요청의 범위가 분명해집니다.
:::

:::page{type="comparison" id="ch02-compare"}
# 모호한 요청을 구체적으로 바꾸기

입력과 처리 결과를 나란히 비교해봅시다.

| 모호한 요청 | 구체적인 요청 |
|---|---|
| 추천해줘 | 시험까지 2주, 하루 2시간의 공부 계획을 추천해줘. |
| 여행 추천해줘 | 2박 3일 부산 여행을 실내 활동 위주로 정리해줘. |
| 건강 관리 알려줘 | 대학생이 실천할 수 있는 생활 습관을 알려줘. |
:::

:::page{type="concept" id="ch02-inputs" layout="basic"}
# 앱에 필요한 입력 데이터

## BMI 계산 앱

책의 입력 예시는 키와 몸무게입니다. 결과에 필요한 정보만 받습니다. BMI 계산은 데이터 처리 연습이며 개인의 건강을 진단하는 기능으로 취급하지 않습니다.

## 병원 접수 앱

책은 이름, 증상, 체온을 입력 예시로 듭니다. 수업에서는 가상 이름과 예시 값을 사용하고, 실제 접수나 응급 판단 기능으로 사용하지 않습니다.
:::

:::page{type="practice-opening" id="ch02-practice-1" practice="002-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 어떤 질문이 더 좋은 답을 만들까?

원본 PDF 10-12쪽 · 실습 002-1.

책의 “공부 계획 알려줘”와 “시험이 2주 남았는데 하루 2시간씩 공부할 수 있어. 효율적인 공부 계획을 짜줘.”를 비교해봅시다. 답변에 상황과 조건이 반영되는지 확인합니다.

> [!TIP]
> 답변의 길이보다 요청한 조건의 반영 여부를 봅니다.

- [ ] 같은 주제의 짧은 질문과 구체적인 질문을 비교했다.
- [ ] 2주와 하루 2시간이라는 조건을 확인했다.
- [ ] 아쉬운 답변은 질문을 다듬어 다시 확인했다.
:::

:::page{type="practice-opening" id="ch02-practice-2" practice="002-2" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 앱에 필요한 입력 데이터 설계하기

원본 PDF 13-15쪽 · 실습 002-2.

원본의 BMI 계산 앱을 기준으로 목적과 입력 데이터를 정해봅시다. 결과를 계산하려면 키와 몸무게가 필요함을 확인하고 입력과 처리의 관계를 정리합니다.

> [!TIP]
> 원본의 입력 데이터 설계 활동이며 건강 판정 기능을 추가하는 과제가 아닙니다.

- [ ] 앱의 목적을 BMI 계산으로 정했다.
- [ ] 필요한 입력을 키와 몸무게로 구분했다.
- [ ] 입력 데이터와 처리 결과의 관계를 설명했다.
:::

:::page{type="concept" id="ch02-request" layout="basic"}
# 책의 질문을 구체적으로 다듬기

## 원본 PDF 10-12쪽

- 짧은 요청: 공부 계획 알려줘.
- 구체적인 요청: 시험까지 2주, 하루 2시간 공부 조건을 포함합니다.
- 여행 질문: 2박 3일 부산 여행, 실내 활동 위주라는 조건을 포함합니다.

## 원본 실습의 확인 기준

같은 주제로 질문을 다듬고 결과를 비교합니다.
:::

:::page{type="practice-checklist" id="ch02-check"}
# 원본 실습의 완료 확인

- [ ] 공부 계획의 2주·하루 2시간 조건을 확인했다.
- [ ] BMI 계산에 필요한 키·몸무게 입력을 설계했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch03-opening" chapter="3"}
# 문제를 단계별로 나누기

## 3차시 · 원본 교재 예시로 배우기

### 학습 목표

- 알고리즘의 의미를 설명할 수 있다.
- 입력, 처리, 출력을 구분할 수 있다.
- 아이디어를 작은 실행 단계로 나눌 수 있다.

### 오늘의 시작

AI의 아이디어를 실제 앱으로 만들려면 사람이 동작 구조를 정해야 합니다. 책의 라면 끓이기와 감정 기록 예시를 사용합니다.
:::

:::page{type="comparison" id="ch03-ramen"}
# 라면 끓이기로 보는 입력·처리·출력

입력과 처리 결과를 나란히 비교해봅시다.

| 단계 | 책의 예시 |
|---|---|
| 입력 | 물, 면, 스프, 냄비 준비 |
| 처리 | 물을 끓이고 재료를 넣어 조리 |
| 출력 | 완성된 라면 |
:::

:::page{type="concept" id="ch03-algorithm" layout="basic"}
# 알고리즘은 해결 절차

## 순서가 필요한 이유

알고리즘은 문제를 해결하기 위한 절차입니다. 필요한 값을 준비하고, 정해 둔 순서로 처리하여 결과를 만듭니다.

## 처리와 출력 구분하기

계산하거나 분류하는 일은 처리입니다. 계산 결과를 화면에 보이게 하는 일은 출력입니다. 같은 문구를 두 단계에 반복해 적지 않습니다.
:::

:::page{type="practice-opening" id="ch03-practice-1" practice="003-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 내 아이디어를 단계별로 나눠보기

원본 PDF 17-18쪽 · 실습 003-1.

원본의 감정 기록 앱 예시를 입력·처리·출력으로 나누어봅시다. 오늘의 기분을 입력하고 감정 상태를 분류한 뒤 결과를 보여주는 순서로 정리합니다.

> [!TIP]
> 감정 분류는 프로그램 구조를 배우기 위한 예시입니다.

- [ ] 입력할 내용을 정리했다.
- [ ] 입력 뒤 처리할 작업을 정리했다.
- [ ] 마지막에 보여줄 결과를 정리했다.
:::

:::page{type="step-process" id="ch03-design"}
# 아이디어를 실행 순서로 만들기

## 입력 정하기

오늘의 기분을 어떤 선택 항목으로 받을지 정합니다.

## 처리 정하기

선택한 항목을 기록하고, 항목에 대응하는 안내를 준비합니다.

## 출력 정하기

선택한 기분과 기록 완료 안내를 보여줍니다.
:::

:::page{type="practice-checklist" id="ch03-check"}
# 원본 실습의 완료 확인

- [ ] 감정 기록 앱의 입력·처리·출력을 구분했다.
- [ ] 각 작업의 순서를 정리했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch04-opening" chapter="4"}
# 순서도와 데이터 이해

## 4차시 · 원본 교재 예시로 배우기

### 학습 목표

- 선언, 입력, 처리, 출력의 역할을 구분할 수 있다.
- 문자열과 숫자를 구분할 수 있다.
- 가족 나이 합과 학생 총점의 원본 흐름을 설명할 수 있다.

### 오늘의 시작

책의 가족 나이 43, 45, 15를 더해봅시다. 선언·입력·처리·출력의 순서로 정리합니다.
:::

:::page{type="concept" id="ch04-roles" layout="basic"}
# 순서도에서 데이터가 이동하는 과정

## 선언과 변수

변수는 값을 저장하고 다시 사용할 때 붙이는 이름입니다. 이름이나 점수처럼 서로 다른 값을 목적에 맞는 변수로 보관합니다.

## 입력·처리·출력

입력에서는 값을 받습니다. 처리에서는 받은 값을 더하거나 비교합니다. 출력에서는 계산 결과나 안내를 보여줍니다. 순서도에서는 역할에 맞는 도형과 연결선을 사용합니다.
:::

:::page{type="comparison" id="ch04-types"}
# 문자열과 숫자 구분하기

입력과 처리 결과를 나란히 비교해봅시다.

| 종류 | 예시 | 사용 방법 |
|---|---|---|
| 문자열 | 이름, 학과, 증상 설명 | 글자로 보관하거나 표시 |
| 정수 | 나이, 점수 | 변환 후 덧셈·비교 |
| 실수 | 키, 체온 | 소수 값을 변환해 계산 |
:::

:::page{type="concept" id="ch04-variables" layout="basic"}
# 변수 이름과 값 맞추기

## 원본 PDF 21쪽

책의 변수 예시는 name에 민수, score에 80을 저장합니다. 원본의 scores·score 혼용과 스마트 따옴표를 바로잡았습니다.

## 두 변수의 역할

- name은 학생 이름을 보관합니다.
- score는 점수를 보관합니다.
- 변수 이름과 저장한 값을 연결하여 읽어봅시다.
:::

:::page{type="practice-opening" id="ch04-practice-1" practice="004-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 우리 가족 나이 합 구하기

원본 PDF 23-24쪽 · 실습 004-1.

엄마 43살, 아빠 45살, 나 15살의 나이를 더하는 순서도를 만들어봅시다. momage, dadage, myage, total을 사용하고 합계 103을 확인합니다.

> [!TIP]
> 원본의 “점수” 표현은 가족 나이에 맞게 고쳤습니다.

- [ ] 책의 세 나이 43·45·15를 사용했다.
- [ ] 세 나이를 더하는 처리를 연결했다.
- [ ] 총합 103을 확인했다.
:::

:::page{type="step-process" id="ch04-family-code"}
# 가족 나이 합 · 원본 문제풀이 순서

## 변수 준비

원본 PDF 23-24쪽의 순서입니다. momage, dadage, myage, total을 준비합니다.

## 나이 입력

각 변수에 책의 43, 45, 15를 넣습니다.

## 합계 처리

total = momage + dadage + myage로 계산합니다.

## 결과 출력

가족 나이의 총합 103을 보여줍니다.
:::

:::page{type="flowchart" id="ch04-family-flow" height="1050"}
# 가족 나이 합의 순서도

값 준비, 입력, 처리, 출력이 서로 다른 역할임을 확인합니다.

```flowchart
control_structure: linear
nodes:
  - id: declare
    role: declaration
    text: momage, dadage, myage, total 준비
  - id: input
    role: input
    text: 43, 45, 15 입력
  - id: sum
    role: process
    text: total = momage + dadage + myage
  - id: out
    role: output
    text: 나이 총합 103 출력
connections:
  - from: declare
    to: input
  - from: input
    to: sum
  - from: sum
    to: out
```

입력 나이가 달라지면 처리 식은 유지되고 총합이 달라집니다.
:::

:::page{type="step-process" id="ch04-scores-code"}
# 학생 세 명의 총점 · 원본 문제풀이

## 변수 준비

원본 PDF 26쪽의 순서입니다. s1, s2, s3, total을 준비합니다.

## 점수 입력

세 학생의 점수를 입력하고 정수로 변환합니다. 원본은 입력 점수 세 개를 미리 지정하지 않습니다.

## 총점 계산

total = s1 + s2 + s3으로 더합니다.

## 총점 출력

학생 세 명의 총점수를 출력합니다. 평균 계산 과제와 구분합니다.
:::

:::page{type="practice-checklist" id="ch04-check"}
# 원본 실습의 완료 확인

- [ ] 43·45·15의 가족 나이 합 103을 확인했다.
- [ ] 학생 세 명의 점수를 더하는 흐름을 설명했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch05-opening" chapter="5"}
# 반복과 누적 이해

## 5차시 · 원본 교재 예시로 배우기

### 학습 목표

- 횟수 반복과 조건 반복을 구분할 수 있다.
- 반복마다 합계를 갱신할 수 있다.
- 10일 운동 시간의 합을 검증할 수 있다.

### 오늘의 시작

책에서는 1일차에 1분, 2일차에 2분, 10일차에 10분 운동합니다. 반복으로 총 운동 시간을 계산해봅시다.
:::

:::page{type="concept" id="ch05-loops" layout="basic"}
# 같은 처리 여러 번 하기

## 횟수와 조건

횟수가 정해져 있으면 그 횟수만큼 반복합니다. while은 조건이 참인 동안 반복하고 거짓이면 멈춥니다. 조건이 참이 될 때까지 반복한다는 설명과 구분합니다.

## 누적하기

누적은 이전 합계에 새 값을 더해 다시 저장하는 처리입니다. 합계를 0으로 준비하는 일은 반복 시작 전에 한 번만 합니다.
:::

:::page{type="comparison" id="ch05-trace"}
# 운동 시간 누적 따라가기

입력과 처리 결과를 나란히 비교해봅시다.

| 날짜 | 더할 시간 | 그날까지 합계 |
|---|---|---|
| 1일차 | 1분 | 1분 |
| 2일차 | 2분 | 3분 |
| 3일차 | 3분 | 6분 |
| 9일차 | 9분 | 45분 |
| 10일차 | 10분 | 55분 |
:::

:::page{type="practice-opening" id="ch05-practice-1" practice="005-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 10일 동안의 운동 시간 누적하기

원본 PDF 31-32쪽 · 실습 005-1.

1일차에 1분, 2일차에 2분씩 운동 시간을 늘려 10일차에 10분 운동합니다. 책의 반복 순서도로 1부터 10까지 더하고 총 55분을 확인해봅시다.

> [!TIP]
> 마지막 10일차를 포함합니다.

- [ ] 처음 합계를 0분으로 정했다.
- [ ] 1일차부터 10일차까지 반복했다.
- [ ] 총 운동 시간 55분을 확인했다.
:::

:::page{type="step-process" id="ch05-exercise-code"}
# 운동 시간 누적 · 원본 의사코드

## 처음 값 설정

원본 PDF 31-32쪽의 순서입니다. time1은 1, total은 0에서 시작합니다.

## 조건 확인

time1 <= 10인 동안 반복합니다.

## 시간 누적

total에 time1을 더하고 time1을 1 증가시킵니다.

## 결과 출력

반복이 끝나면 총 운동 시간 55분을 출력합니다.
:::

:::page{type="flowchart" id="ch05-exercise-flow" height="1050"}
# 운동 시간 누적 순서도

책의 31쪽 누적 구조를 마지막 날짜까지 따라가봅시다.

```flowchart
control_structure: loop
nodes:
  - id: start
    role: declaration
    text: time1 = 1, total = 0
  - id: cond
    role: decision
    text: time1 <= 10인가?
  - id: sum
    role: process
    text: total = total + time1
  - id: next
    role: process
    text: time1 = time1 + 1
  - id: out
    role: output
    text: 총 운동 시간 출력
connections:
  - from: start
    to: cond
  - from: cond
    to: sum
    label: YES
  - from: sum
    to: next
  - from: next
    to: cond
  - from: cond
    to: out
    label: NO
```

조건이 거짓이 되면 반복 밖에서 총합을 출력합니다.
:::

:::page{type="practice-opening" id="ch05-practice-2" practice="005-2" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 하루 카페인 섭취량 누적하기

원본 PDF 27쪽 · 실습 004-2.

책의 카페인 누적 실습을 따라 처음 총량을 0mg으로 정합니다. 음료의 카페인 양을 입력할 때마다 더하고, 입력이 끝나면 총량을 출력합니다. 원본은 각 음료의 입력값을 지정하지 않습니다.

> [!TIP]
> 원본의 하루·일주일 표현을 제목에 맞게 하루로 통일했습니다.

- [ ] 처음 총 카페인 양을 0mg으로 정했다.
- [ ] 음료 입력을 반복해 총량에 더했다.
- [ ] 입력이 끝났을 때 총량을 출력했다.
:::

:::page{type="step-process" id="ch05-caffeine-code"}
# 카페인 누적 · 원본 입력 반복

## 총량 준비

원본 PDF 27쪽의 순서입니다. 총 카페인 양을 0mg으로 시작합니다.

## 음료 값 더하기

음료의 카페인 양을 입력하고 현재 총량에 더합니다.

## 입력 반복

더 입력할 내용이 있으면 같은 작업을 반복합니다.

## 최종 총량 출력

입력이 끝나면 누적한 총량을 출력합니다.
:::

:::page{type="practice-checklist" id="ch05-check"}
# 원본 실습의 완료 확인

- [ ] 1일차부터 10일차까지 총 55분을 확인했다.
- [ ] 카페인 입력을 반복하고 총량을 출력했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch06-opening" chapter="6"}
# 조건에 따라 결과 나누기

## 6차시 · 원본 교재 예시로 배우기

### 학습 목표

- if, elif, else의 역할을 설명할 수 있다.
- 조건을 검사하는 순서를 정할 수 있다.
- 경계값을 넣어 결과를 확인할 수 있다.

### 오늘의 시작

책의 비 오는 날 우산 예시와 수면 시간 분류로 조건문을 이해합니다. 수면 문구는 책의 분류 규칙을 연습하는 예시이며 건강 판정은 아닙니다.
:::

:::page{type="concept" id="ch06-conditions" layout="basic"}
# 조건문 읽는 방법

## if와 else

if는 조건이 참일 때 실행할 내용을 정합니다. else는 앞의 조건에 해당하지 않을 때 실행할 내용을 정합니다.

## elif와 순서

elif는 앞 조건이 거짓일 때 다음 조건을 검사합니다. 한 번 참인 분기를 선택하면 이어지는 elif와 else는 실행하지 않습니다.
:::

:::page{type="comparison" id="ch06-sleep-rules"}
# 책의 수면 시간 분류 규칙

책 36쪽의 분기 규칙을 그대로 연습합니다. 실제 건강 기준으로 일반화하지 않습니다.

| 수면 시간 | 학습용 출력 |
|---|---|
| 8시간 이상 | 충분한 수면입니다 |
| 5시간 이상, 8시간 미만 | 적정 수면입니다 |
| 5시간 미만 | 수면 부족입니다 |
:::

:::page{type="practice-opening" id="ch06-practice-1" practice="006-1" practice-kind="본문 예시 따라하기" platform="알고플로에서 실습하기"}
# 수면 시간에 따른 안내 · 원본 순서도

원본 PDF 36쪽 · 조건문 본문 예시.

원본의 수면 시간 순서도를 따라봅시다. 8시간 이상인지 먼저 판단하고, 아니면 5시간 이상인지 판단하여 책의 세 안내 문구 중 하나를 출력합니다.

> [!TIP]
> 책의 조건문 학습용 규칙입니다.

- [ ] 8시간 이상 조건을 먼저 확인했다.
- [ ] 그렇지 않을 때 5시간 이상 조건을 확인했다.
- [ ] 충분한 수면·적정 수면·수면 부족의 세 출력을 구분했다.
:::

:::page{type="step-process" id="ch06-sleep-code"}
# 수면 시간 · 원본 조건 처리

## 입력받기

원본 PDF 36쪽의 순서입니다. 수면 시간을 입력받습니다. 책은 하나의 고정 입력 시간을 지정하지 않습니다.

## 첫 조건 판단

8시간 이상이면 “충분한 수면입니다”를 출력합니다.

## 다음 조건 판단

8시간 미만일 때 5시간 이상이면 “적정 수면입니다”를 출력합니다.

## 나머지 경우

5시간 미만이면 “수면 부족입니다”를 출력합니다.
:::

:::page{type="flowchart" id="ch06-sleep-flow" height="1050"}
# 수면 시간 조건 순서도

두 조건을 검사하는 순서와 YES, NO 연결을 구분합니다.

```flowchart
control_structure: if-else-if
nodes:
  - id: input
    role: input
    text: 수면 시간 입력
  - id: eight
    role: decision
    text: 8시간 이상인가?
  - id: five
    role: decision
    text: 5시간 이상인가?
  - id: enough
    role: output
    text: 충분한 수면입니다
  - id: normal
    role: output
    text: 적정 수면입니다
  - id: low
    role: output
    text: 수면 부족입니다
connections:
  - from: input
    to: eight
  - from: eight
    to: enough
    label: YES
  - from: eight
    to: five
    label: NO
  - from: five
    to: normal
    label: YES
  - from: five
    to: low
    label: NO
```

잘못된 입력을 검사하는 단계는 이 분류 앞에서 따로 설계합니다.
:::

:::page{type="concept" id="ch06-fix" layout="basic"}
# 책의 조건 검사 순서 읽기

## 원본 PDF 36쪽

8시간 이상인 값은 5시간 이상에도 해당합니다. 원본 순서도는 8시간 조건부터 확인하고, 해당하지 않을 때 다음 조건으로 이동합니다.

## 연결 확인

첫 조건의 NO가 두 번째 조건으로 이어지는지 확인합니다. 각 YES와 마지막 NO는 해당 안내 문구로 연결합니다.
:::

:::page{type="practice-checklist" id="ch06-check"}
# 원본 실습의 완료 확인

- [ ] 8시간 조건과 5시간 조건의 순서를 확인했다.
- [ ] 원본의 세 출력 문구를 올바르게 연결했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch07-opening" chapter="7"}
# 반복과 조건 함께 사용하기

## 7차시 · 원본 교재 예시로 배우기

### 학습 목표

- 반복할 작업과 판단할 조건을 분리할 수 있다.
- 학생 수만큼 결과를 출력할 수 있다.
- 합격 기준과 관람 기준을 구분할 수 있다.

### 오늘의 시작

책에서는 여러 학생의 점수나 나이를 하나씩 확인합니다. 학생을 세는 반복과 각 학생의 조건 판단을 함께 사용합니다.
:::

:::page{type="comparison" id="ch07-roles"}
# 반복과 조건의 서로 다른 역할

입력과 처리 결과를 나란히 비교해봅시다.

| 구조 | 점수 확인 예시 |
|---|---|
| 반복 | 학생 점수를 한 명씩 확인 |
| 조건 | 기준 점수 이상인지 확인 |
| 출력 | 그 학생의 결과를 표시 |
:::

:::page{type="practice-opening" id="ch07-practice-1" practice="007-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 입력받은 학생 수만큼 점수 통과 여부 확인

원본 PDF 40쪽 · 실습 007-1.

학생 수 N을 정하고 각 학생의 점수를 입력받아봅시다. 원본 기준에 따라 80점 이상이면 PASS, 80점 미만이면 FAIL을 출력합니다. 점수 목록을 세 개로 고정하지 않습니다.

> [!TIP]
> 원본 38쪽의 60점 설명 예시와 40쪽의 80점 실습 기준을 구분합니다.

- [ ] 입력받은 학생 수 N만큼 처리했다.
- [ ] 80점 이상과 미만을 구분했다.
- [ ] 학생마다 PASS 또는 FAIL을 출력했다.
:::

:::page{type="step-process" id="ch07-pass-code"}
# 학생 수 N을 사용하는 원본 실습 순서

## 학생 수 정하기

원본 PDF 40쪽의 순서입니다. 처리할 학생 수 N을 입력받고 반복 변수를 0에서 시작합니다.

## 점수 입력

학생 한 명의 점수를 입력받습니다.

## 통과 여부 출력

80점 이상이면 PASS, 80점 미만이면 FAIL을 출력합니다.

## 다음 학생 처리

반복 변수를 1 증가시키고 N명 처리가 끝날 때까지 반복합니다.
:::

:::page{type="flowchart" id="ch07-pass-flow" height="1050"}
# 점수 확인의 반복과 분기

각 학생의 결과를 출력한 뒤 학생 수를 한 번 증가시킵니다.

```flowchart
control_structure: loop
nodes:
  - id: start
    role: declaration
    text: i = 0, N = 학생 수
  - id: loop
    role: decision
    text: i < N인가?
  - id: input
    role: input
    text: 학생 점수 입력
  - id: pass
    role: decision
    text: 점수가 80 이상인가?
  - id: yes
    role: output
    text: PASS 출력
  - id: no
    role: output
    text: FAIL 출력
  - id: next
    role: process
    text: i = i + 1
  - id: end
    role: output
    text: 전체 처리 완료
connections:
  - from: start
    to: loop
  - from: loop
    to: input
    label: YES
  - from: input
    to: pass
  - from: pass
    to: yes
    label: YES
  - from: pass
    to: no
    label: NO
  - from: yes
    to: next
  - from: no
    to: next
  - from: next
    to: loop
  - from: loop
    to: end
    label: NO
```

입력 학생 수와 결과 개수가 같아야 합니다.
:::

:::page{type="step-process" id="ch07-movie-code"}
# 영화 관람 가능 여부 · 원본 문제풀이

## 네 학생의 나이 입력

원본 PDF 39쪽의 순서입니다. 원본처럼 학생 네 명의 나이를 하나씩 입력받습니다. 별도의 네 나이 목록은 제시하지 않습니다.

## 관람 조건 판단

책에 주어진 15세 이상 조건을 확인합니다.

## 결과 출력

각 학생에 대해 관람가능 또는 관람불가를 출력합니다.

## 네 번 반복

네 학생 모두에게 결과가 출력되었는지 확인합니다.
:::

:::page{type="practice-checklist" id="ch07-check"}
# 원본 실습의 완료 확인

- [ ] N명의 점수에 80점 PASS 기준을 적용했다.
- [ ] 네 학생 나이의 15세 관람 조건을 설명했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch08-opening" chapter="8"}
# Button·Field·Text로 첫 화면 만들기

## 8차시 · 원본 교재 예시로 배우기

### 학습 목표

- GUI와 위젯의 의미를 설명할 수 있다.
- 버튼 이벤트와 입력값을 연결할 수 있다.
- 메시지 출력과 Field 추가·삭제를 확인할 수 있다.

### 오늘의 시작

책의 바이브 프로젝트는 프로젝트 정보, 위젯 역할, 이벤트, 추가 설명을 작성한 뒤 코드를 생성합니다. 화면 구성과 버튼 동작을 따로 설계해봅시다.
:::

:::page{type="comparison" id="ch08-widgets"}
# 기본 위젯의 역할

입력과 처리 결과를 나란히 비교해봅시다.

| 위젯 | 역할 | 책의 이름 |
|---|---|---|
| Button | 눌렀을 때 기능 실행 | btn1 |
| Field | 글자나 숫자 입력 | fld1, fld2 |
| Text | 설명과 결과 표시 | txt1 |
:::

:::page{type="step-process" id="ch08-designer"}
# 책의 바이브 프로젝트 작성 순서

## 프로젝트 정보 정하기

프로젝트 이름과 설명을 적습니다.

## 위젯 역할 정하기

디자이너에서 위젯을 추가하고 이름과 역할을 확인합니다.

## 이벤트 정하기

각 버튼을 눌렀을 때 바뀔 내용을 적습니다.

## 생성 후 실행하기

코드를 생성하고 버튼을 실제로 눌러 동작을 확인합니다.
:::

:::page{type="practice-opening" id="ch08-practice-1" practice="008-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 버튼 클릭하면 배경색과 글자색 바꾸기

원본 PDF 44-46쪽 · 실습 008-1.

Flet 디자이너에 btn1을 추가하고 클릭 이벤트를 작성해봅시다. 책처럼 버튼을 누르면 배경색은 blue, 글자색은 white로 바뀌게 합니다.

> [!TIP]
> 원본의 btn1.bgcolor와 btn1.color 역할을 구분합니다.

- [ ] btn1을 화면에 추가했다.
- [ ] 클릭 이벤트에 blue와 white를 지정했다.
- [ ] 클릭 후 배경색과 글자색을 함께 확인했다.
:::

:::page{type="concept" id="ch08-button-before" layout="basic"}
# 버튼 클릭 전

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

클릭 전에는 밝은 배경의 Button이 보입니다.

::image{src="assets/source-20261006/button-before.png" alt="클릭 전에는 밝은 배경의 Button이 보입니다." ratio="170:84" width="half" caption="원본 PDF 46쪽의 실습 화면"}
:::

:::page{type="concept" id="ch08-button-after" layout="basic"}
# 버튼 클릭 후

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

클릭 후에는 같은 버튼의 배경이 파란색으로 바뀝니다.

::image{src="assets/source-20261006/button-after.png" alt="클릭 후에는 같은 버튼의 배경이 파란색으로 바뀝니다." ratio="183:82" width="half" caption="원본 PDF 46쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch08-practice-message" practice="008-2" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 버튼 클릭하면 메시지 창 출력하기

원본 PDF 49-51쪽 · 실습 008-2.

Field에 “안녕하세요”를 입력하고 Button을 눌러 메시지 창에 입력값이 나타나도록 만들어봅시다. fld1과 btn1을 연결하고 원본의 입력 화면과 알림 창을 비교합니다.

> [!TIP]
> message는 수업 도구 전용 기능이며 독립 Python의 기본 함수가 아닙니다.

- [ ] fld1과 btn1을 화면에 추가했다.
- [ ] 버튼 이벤트가 fld1의 값을 읽는다.
- [ ] 메시지 창에 입력한 인사말이 나타난다.
:::

:::page{type="concept" id="ch08-message-screen" layout="basic"}
# 원본의 입력 화면과 메시지 창

## 입력 화면

책처럼 fld1에 안녕하세요를 입력합니다.

::image{src="assets/source-20261010/message-dialog.png" alt="원본 실습의 안녕하세요 입력창과 Button" ratio="462:274" width="half" caption="원본 PDF 49쪽의 입력 화면"}

## 클릭 결과

버튼을 클릭하면 알림 창에서 같은 입력 내용을 확인합니다.

::image{src="assets/source-20261010/message-input.png" alt="원본 실습의 안녕하세요 알림 창" ratio="424:247" width="half" caption="원본 PDF 49쪽의 메시지 창"}
:::

:::page{type="practice-opening" id="ch08-practice-2" practice="008-3" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# Field에 입력한 내용 버튼으로 출력하기

원본 PDF 52-53쪽 · 실습 008-3.

원본처럼 fld1에 “안녕”을 입력하고 추가 버튼을 눌러 fld2에 내용을 표시해봅시다. 삭제 버튼을 누르면 두 Field의 내용이 모두 지워지는지 확인합니다.

> [!TIP]
> 처음 상태에서 추가 버튼을 한 번 눌러 원본 그림과 비교합니다.

- [ ] fld1·fld2와 추가·삭제 버튼을 배치했다.
- [ ] 추가 후 원본 그림처럼 fld2에 안녕이 보인다.
- [ ] 삭제 후 두 Field의 내용이 지워진다.
:::

:::page{type="step-process" id="ch08-request"}
# Field 실습 · 원본 이벤트 설정

## UI 배치

원본 PDF 52-53쪽의 순서입니다. fld1, fld2, btn1, btn2를 책의 배치대로 추가합니다.

## 추가 버튼

btn1을 클릭하면 fld1에 입력한 내용을 fld2에 표시하도록 역할과 이벤트를 적습니다.

## 삭제 버튼

btn2를 클릭하면 fld1과 fld2의 내용을 모두 지우도록 적습니다.

## 실행 확인

프로젝트를 생성한 뒤 안녕 입력·추가·삭제를 순서대로 확인합니다.
:::

:::page{type="concept" id="ch08-field-copy" layout="basic"}
# 입력값을 복사한 화면

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

위 입력창의 안녕이 추가 버튼을 누른 뒤 아래 입력창에도 표시됩니다.

::image{src="assets/source-20261006/field-copy.png" alt="위 입력창의 안녕이 추가 버튼을 누른 뒤 아래 입력창에도 표시됩니다." ratio="497:406" width="half" caption="원본 PDF 53쪽의 실습 화면"}
:::

:::page{type="concept" id="ch08-platform" layout="basic"}
# 책의 이름과 Python API 구분하기

## 수업 도구의 이름

책의 Field는 디자이너에서 쓰는 이름입니다. Flet Python 코드에서는 TextField와 연결됩니다. btn1, fld1, txt1은 수업 도구에서 지정한 위젯 변수 이름입니다.

## 화면 갱신

값을 바꾸는 코드와 화면에 변경을 반영하는 과정이 연결되어야 합니다. 생성된 코드를 수정할 때는 수업 도구의 실행 구조와 갱신 방식을 확인합니다.
:::

:::page{type="practice-checklist" id="ch08-check"}
# 원본 실습의 완료 확인

- [ ] 버튼의 blue·white 변경을 확인했다.
- [ ] 입력 인사말을 메시지 창에 표시했다.
- [ ] Field 추가·삭제를 원본과 비교했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch09-opening" chapter="9"}
# 계산·누적 출력 앱 만들기

## 9차시 · 원본 교재 예시로 배우기

### 학습 목표

- 반복 알고리즘을 GUI 이벤트로 연결할 수 있다.
- 계산 입력을 숫자로 변환할 수 있다.
- 값 교체와 내용 누적을 구분할 수 있다.

### 오늘의 시작

책의 누적곱, 두 수 계산기, Text 누적, 구구단 실습을 연결합니다. 계산은 입력한 숫자와 선택한 연산을 명확히 정해 처리합니다.
:::

:::page{type="practice-opening" id="ch09-practice-1" practice="009-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# Field에 입력한 두 수의 누적곱 출력

원본 PDF 54-55쪽 · 실습 008-4.

책의 화면처럼 fld1에 1, fld2에 6을 넣고 누적 버튼을 눌러봅시다. 1부터 6까지의 곱 720이 fld3에 표시되는지 확인합니다. 다시 누르면 현재 입력으로 결과를 바꿉니다.

> [!TIP]
> 곱을 누적할 처음 값은 1입니다.

- [ ] fld1·fld2·fld3과 누적 버튼을 배치했다.
- [ ] 책의 1과 6으로 결과 720을 확인했다.
- [ ] 다시 실행하면 현재 값으로 결과가 바뀐다.
:::

:::page{type="step-process" id="ch09-product-code"}
# 누적곱 프로그램의 원본 동작

## 두 수 입력

원본 PDF 54-55쪽의 순서입니다. 책의 시작 값 1과 끝 값 6을 각 Field에 입력합니다.

## 버튼 이벤트 설정

두 수 사이의 값을 곱하도록 누적 버튼의 역할을 작성합니다.

## 결과 표시

fld3에서 720을 확인합니다.

## 재실행

새 입력으로 다시 누르면 이전 결과를 현재 계산 결과로 바꿉니다.
:::

:::page{type="concept" id="ch09-product" layout="basic"}
# 누적곱 결과 화면

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

시작 1, 끝 6을 입력하고 누적 버튼을 누르면 결과창에 720이 보입니다.

::image{src="assets/source-20261006/product.png" alt="시작 1, 끝 6을 입력하고 누적 버튼을 누르면 결과창에 720이 보입니다." ratio="940:286" width="text" caption="원본 PDF 54쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch09-practice-2" practice="009-2" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 계산기 프로그램 2

원본 PDF 61-62쪽 · 실습 008-5.

fld1과 fld2에 두 숫자를 입력합니다. 연산 버튼을 눌러 +, -, *, /를 차례로 바꾸고 = 버튼으로 계산합니다. 책의 100과 5, 나눗셈을 사용해 결과 20.0을 확인해봅시다.

> [!TIP]
> 원본의 두 수 계산기를 사용하며 자유 입력 수식을 eval로 실행하지 않습니다.

- [ ] 두 Field와 연산·계산 버튼을 배치했다.
- [ ] 연산 기호가 순서대로 바뀐다.
- [ ] 100 / 5의 결과 20.0이 보인다.
:::

:::page{type="step-process" id="ch09-calculator-request"}
# 계산기 2 · 원본 위젯과 이벤트

## 입력 위젯

원본 PDF 61-62쪽의 순서입니다. fld1과 fld2는 각각 계산할 숫자를 받습니다.

## 연산 버튼

btn1을 누르면 연산 기호가 +, -, *, / 순서로 바뀝니다.

## 계산 버튼

btn2를 누르면 현재 기호에 따라 두 값을 계산합니다.

## 결과 확인

원본 62쪽 화면의 결과 표시 위젯 txt1에서 값을 확인합니다. 본문의 세 번째 Field 표현과 캡처를 구분합니다.
:::

:::page{type="concept" id="ch09-calculator" layout="basic"}
# 두 수 계산기 결과

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

100과 5, 나누기 기호가 표시되고 결과창에는 20.0이 보입니다.

::image{src="assets/source-20261006/calculator.png" alt="100과 5, 나누기 기호가 표시되고 결과창에는 20.0이 보입니다." ratio="452:215" width="half" caption="원본 PDF 61쪽의 실습 화면"}
:::

:::page{type="concept" id="ch09-calculator-code" layout="basic"}
# 책의 두 계산기 예시 구분하기

## 원본 PDF 56-62쪽

원본에는 수식 전체를 입력하는 계산기와 두 수를 입력하는 계산기가 있습니다. 이번 차시는 61-62쪽 계산기 2의 입력·연산·출력을 그대로 따라갑니다.

## 실습 범위

두 숫자와 선택한 사칙연산을 처리합니다. 수식 전체를 eval로 실행하는 예시는 따라쓰기 코드로 넣지 않았습니다.
:::

:::page{type="practice-opening" id="ch09-practice-3" practice="009-3" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# Text에 원하는 내용 추가 프로그램

원본 PDF 63-64쪽 · 실습 008-6.

fld1에 내용을 입력하고 추가 버튼을 눌러 txt1에 표시해봅시다. 원본 화면처럼 이전에 표시한 내용과 새로 추가한 내용을 함께 확인합니다.

> [!TIP]
> Text 출력과 Field 입력의 역할을 구분합니다.

- [ ] fld1·btn1·txt1을 배치했다.
- [ ] 추가 버튼이 fld1의 내용을 txt1에 넣는다.
- [ ] 원본 화면과 추가된 내용을 비교했다.
:::

:::page{type="concept" id="ch09-text" layout="basic"}
# Text에 두 문장을 추가한 화면

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

추가한 안녕하세요 저는 코알라입니다와 저는 12살입니다가 두 줄로 표시됩니다.

::image{src="assets/source-20261006/text-append.png" alt="추가한 안녕하세요 저는 코알라입니다와 저는 12살입니다가 두 줄로 표시됩니다." ratio="393:234" width="half" caption="원본 PDF 63쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch09-practice-4" practice="009-4" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 원하는 단 구구단 출력하기

원본 PDF 65-66쪽 · 실습 008-7.

fld1에 원하는 단을 입력하고 버튼을 눌러 txt1에 구구단을 출력해봅시다. 책의 4단 화면과 4 × 1부터 4 × 9까지의 결과를 비교합니다.

> [!TIP]
> 버튼 클릭과 반복 출력을 연결합니다.

- [ ] fld1·btn1·txt1을 배치했다.
- [ ] 입력한 단의 구구단이 출력된다.
- [ ] 책의 4단 아홉 줄과 비교했다.
:::

:::page{type="step-process" id="ch09-times-code"}
# 구구단 실습 · 원본 프로그램 순서

## 단 입력

원본 PDF 65-66쪽의 순서입니다. 책의 화면처럼 fld1에 4를 넣습니다.

## 이벤트 설정

btn1을 눌렀을 때 입력한 단의 구구단을 출력하도록 적습니다.

## 반복 출력

곱하는 수 1부터 9까지의 결과를 txt1에 출력합니다.

## 원본과 대조

4단의 아홉 줄을 책의 결과 화면과 비교합니다.
:::

:::page{type="concept" id="ch09-times" layout="basic"}
# 책의 4단 출력 화면

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

입력값 4와 4단의 아홉 줄 결과가 함께 보입니다.

::image{src="assets/source-20261006/times-table.png" alt="입력값 4와 4단의 아홉 줄 결과가 함께 보입니다." ratio="489:257" width="half" caption="원본 PDF 65쪽의 실습 화면"}
:::

:::page{type="practice-checklist" id="ch09-check"}
# 원본 실습의 완료 확인

- [ ] 1부터 6까지의 누적곱 720을 확인했다.
- [ ] 계산기 2의 100 / 5 = 20.0을 확인했다.
- [ ] Text 추가와 4단 출력을 원본과 비교했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch10-opening" chapter="10"}
# 선택 위젯과 진행 표시

## 10차시 · 원본 교재 예시로 배우기

### 학습 목표

- Dropdown, Checkbox, RadioButton의 차이를 설명할 수 있다.
- 선택한 값과 안내를 연결할 수 있다.
- 진행률의 범위를 확인할 수 있다.

### 오늘의 시작

책의 색상 선택, 건강습관 체크, 동아리 소개, 진행 막대 예시로 한 가지 선택과 여러 가지 선택을 비교합니다.
:::

:::page{type="comparison" id="ch10-choice"}
# 선택 방식 비교

입력과 처리 결과를 나란히 비교해봅시다.

| 위젯 | 선택 방식 | 책의 예시 |
|---|---|---|
| Dropdown | 목록에서 하나 | 색상 선택 |
| Checkbox | 항목별 선택·해제 | 건강습관 |
| RadioButton | 같은 그룹에서 하나 | 동아리 소개 |
| ProgressBar | 진행 정도 표시 | 0.1씩 증가·감소 |
:::

:::page{type="practice-opening" id="ch10-practice-1" practice="010-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# Dropdown을 추가하고 선택한 값 확인

원본 PDF 68-70쪽 · 실습 008-8.

fld1에 새 항목을 입력하고 버튼을 눌러 ddl1 목록에 추가해봅시다. 목록에서 항목을 선택하면 선택한 값이 txt1에 출력되는지 확인합니다.

> [!TIP]
> 항목 추가 버튼과 Dropdown 선택 이벤트를 각각 설정합니다.

- [ ] fld1·ddl1·btn1·txt1을 배치했다.
- [ ] 입력한 항목이 목록에 추가된다.
- [ ] 선택한 값이 txt1에 출력된다.
:::

:::page{type="concept" id="ch10-dropdown" layout="basic"}
# 목록의 선택값 확인하기

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

목록에서 선택한 빨강이 결과 영역에 표시됩니다.

::image{src="assets/source-20261006/dropdown.png" alt="목록에서 선택한 빨강이 결과 영역에 표시됩니다." ratio="334:304" width="half" caption="원본 PDF 68쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch10-practice-2" practice="010-2" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 오늘의 건강습관 체크 프로그램

원본 PDF 73-75쪽 · 실습 009-1.

원본의 네 건강습관 Checkbox를 배치해봅시다. 오늘 실천한 항목을 선택하고 결과 확인 버튼으로 선택된 습관의 이름과 개수를 Text에 출력합니다.

> [!TIP]
> 원본의 체크 활동이며 별도의 건강 점수나 진단 기능을 만들지 않습니다.

- [ ] chk1부터 chk4까지 배치했다.
- [ ] 선택한 습관 이름을 출력했다.
- [ ] 선택한 항목의 개수를 함께 출력했다.
:::

:::page{type="concept" id="ch10-health" layout="basic"}
# 책의 건강습관 체크 화면

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

네 가지 습관을 각각 체크하고 확인 버튼을 누르는 화면입니다.

::image{src="assets/source-20261006/health-check.png" alt="네 가지 습관을 각각 체크하고 확인 버튼을 누르는 화면입니다." ratio="235:323" width="half" caption="원본 PDF 73쪽의 실습 화면"}
:::

:::page{type="step-process" id="ch10-health-request"}
# 건강습관 실습 · 원본 버튼 이벤트

## 건강습관 선택

원본 PDF 73-75쪽의 순서입니다. 원본 화면의 네 항목 중 실천한 항목을 체크합니다.

## 선택값 읽기

btn1은 각 Checkbox의 선택 여부를 읽습니다.

## 이름과 개수 출력

선택한 습관의 이름과 총개수를 Text에 출력합니다.
:::

:::page{type="practice-opening" id="ch10-practice-3" practice="010-3" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 선택한 동아리 소개 프로그램

원본 PDF 78-80쪽 · 실습 009-2.

원본의 코딩·방송·미술·과학 동아리를 Radio 그룹에 배치해봅시다. 한 동아리를 선택하고 확인 버튼을 누르면 이름과 안내 내용이 txt1에 표시되게 합니다.

> [!TIP]
> 원본 실행 화면의 과학 동아리 선택 상태와 비교합니다.

- [ ] rad1부터 rad4까지 같은 그룹에 넣었다.
- [ ] 한 동아리만 선택할 수 있다.
- [ ] 선택한 동아리 이름과 안내가 txt1에 보인다.
:::

:::page{type="concept" id="ch10-club" layout="basic"}
# 한 동아리만 선택한 화면

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

과학 동아리가 선택되고 과학 실험과 탐구 활동 소개가 표시됩니다.

::image{src="assets/source-20261006/club-radio.png" alt="과학 동아리가 선택되고 과학 실험과 탐구 활동 소개가 표시됩니다." ratio="384:240" width="half" caption="원본 PDF 78쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch10-practice-4" practice="010-4" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# ProgressBar 버튼 2개로 증가·감소

원본 PDF 82-83쪽 · 실습 009-3.

prg1의 처음 값을 0.0으로 설정해봅시다. 증가 버튼은 0.1을 더하고 감소 버튼은 0.1을 빼도록 설정합니다. 책 81쪽의 범위 0.0부터 1.0을 확인합니다.

> [!TIP]
> 책의 value 범위와 버튼 증감값을 구분합니다.

- [ ] prg1과 두 버튼을 배치했다.
- [ ] 증가·감소에 따라 0.1씩 바뀐다.
- [ ] 0.0부터 1.0 범위를 확인했다.
:::

:::page{type="concept" id="ch10-progress" layout="basic"}
# 진행 막대와 두 버튼

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

진행 막대 아래에 증가와 감소 버튼이 있습니다. 원본 화면은 중간 진행 상태를 보여줍니다.

::image{src="assets/source-20261006/progress.png" alt="진행 막대 아래에 증가와 감소 버튼이 있습니다. 원본 화면은 중간 진행 상태를 보여줍니다." ratio="292:125" width="half" caption="원본 PDF 82쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch10-practice-5" practice="010-5" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# Image 구성하기

원본 PDF 85-87쪽 · 실습 009-6.

책처럼 Image 두 개를 불러오고 각각 크기를 설정해봅시다. 이미지 사이에 Divider를 넣고 세로로 구분되어 보이는지 확인합니다.

> [!TIP]
> 이미지가 보이지 않으면 인터넷 연결과 이미지 주소를 확인합니다.

- [ ] Image 두 개를 화면에 배치했다.
- [ ] width와 height로 크기를 설정했다.
- [ ] 두 이미지 사이에 Divider가 보인다.
:::

:::page{type="concept" id="ch10-images" layout="basic"}
# 두 이미지와 구분선

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

두 이미지 사이에 얇은 구분선이 있어 화면 영역이 나뉩니다.

::image{src="assets/source-20261006/image-divider.png" alt="두 이미지 사이에 얇은 구분선이 있어 화면 영역이 나뉩니다." ratio="266:232" width="half" caption="원본 PDF 85쪽의 실습 화면"}
:::

:::page{type="practice-checklist" id="ch10-check"}
# 원본 실습의 완료 확인

- [ ] Dropdown의 항목 추가·선택을 확인했다.
- [ ] Checkbox와 Radio 선택 결과를 확인했다.
- [ ] 진행 막대 증감과 두 이미지·Divider를 확인했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch11-opening" chapter="11"}
# 학생 성적을 표로 정리하기

## 11차시 · 원본 교재 예시로 배우기

### 학습 목표

- 표의 행, 열, 셀을 구분할 수 있다.
- 입력 순서와 표 열 순서를 맞출 수 있다.
- 화면 번호와 리스트 인덱스를 연결할 수 있다.

### 오늘의 시작

책의 학생 성적 Table 실습을 사용합니다. 설명과 캡처의 과목 순서가 달라, 이번 원고는 캡처처럼 이름·국어·수학·영어 순서로 통일합니다.
:::

:::page{type="concept" id="ch11-table" layout="basic"}
# DataTable의 구조

## 행과 열

열은 이름, 국어, 수학, 영어처럼 같은 종류의 항목입니다. 행은 학생 한 명의 기록입니다. 셀은 행과 열이 만나는 한 칸입니다.

## Flet 코드와 연결

DataColumn은 열 제목, DataRow는 한 행, DataCell은 한 칸을 구성합니다. 화면에서 보이는 열 이름과 실제 값을 넣는 순서를 맞춥니다.
:::

:::page{type="practice-opening" id="ch11-practice-1" practice="011-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 학생 성적을 Table에 기록하기

원본 PDF 90-92쪽 · 실습 009-7.

fld1부터 fld4까지 학생 이름과 국어·수학·영어 점수를 입력해봅시다. 추가하기 버튼을 누르면 tbl1에 한 행이 기록되는지 원본 화면과 비교합니다. 과목 순서는 캡처에 맞춥니다.

> [!TIP]
> 원본 본문의 국어·영어·수학 순서와 캡처의 순서 차이를 바로잡았습니다.

- [ ] 입력창과 표의 이름·국어·수학·영어 순서를 맞췄다.
- [ ] 추가하기를 누르면 표에 한 행이 기록된다.
- [ ] 입력값과 표의 각 칸을 대조했다.
:::

:::page{type="concept" id="ch11-table-screen" layout="basic"}
# 책의 학생 성적 Table

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

표 열은 이름, 국어, 수학, 영어입니다. 학생1은 100, 90, 80으로 표시됩니다.

::image{src="assets/source-20261006/student-table.png" alt="표 열은 이름, 국어, 수학, 영어입니다. 학생1은 100, 90, 80으로 표시됩니다." ratio="744:381" width="text" caption="원본 PDF 90쪽의 실습 화면"}
:::

:::page{type="comparison" id="ch11-field-map"}
# 입력창과 표 열 대조

입력과 처리 결과를 나란히 비교해봅시다.

| 입력창 | 표 열 | 연습 입력 |
|---|---|---|
| fld1 | 이름 | 학생1 |
| fld2 | 국어 | 100 |
| fld3 | 수학 | 90 |
| fld4 | 영어 | 80 |
:::

:::page{type="step-process" id="ch11-request"}
# Table 실습 · 원본 입력과 추가

## 위젯 배치

원본 PDF 90-92쪽의 순서입니다. fld1부터 fld4, btn1, tbl1을 책의 화면대로 구성합니다.

## 입력창 역할

fld1은 이름, fld2는 국어, fld3은 수학, fld4는 영어로 정합니다.

## 추가 이벤트

btn1은 입력한 네 값을 표의 같은 순서로 추가합니다.

## 화면 대조

원본 화면에 있는 학생1의 100·90·80과 표의 열을 비교합니다.
:::

:::page{type="concept" id="ch11-index" layout="basic"}
# 왜 위치 번호에서 1을 뺄까?

## 화면의 번호

사용자는 첫 번째 행을 1행이라고 부릅니다. Python 리스트의 첫 위치는 0입니다. 따라서 화면의 2행은 리스트 위치 1과 대응합니다.

## 확인할 범위

번호를 숫자로 바꾼 뒤 실제 행과 열 범위에 있는지 확인합니다. 번호 0을 허용하면 1을 뺐을 때 -1이 되어 마지막 위치를 가리킬 수 있습니다.
:::

:::page{type="step-process" id="ch11-index-code"}
# 행·열 번호를 리스트 위치로 바꾸기

## 화면 번호 확인

원본 PDF 89쪽의 순서입니다. 원본 예시처럼 화면에서 2행을 선택했다고 생각해봅시다.

## 리스트 위치 변환

첫 행의 인덱스는 0, 둘째 행의 인덱스는 1입니다. 선택한 행·열 번호에서 각각 1을 뺍니다.

## 선택한 셀 확인

변환한 행과 열 위치가 원하는 DataCell에 해당하는지 확인합니다.
:::

:::page{type="step-process" id="ch11-practice-2"}
# 표의 값 변경 · 원본 본문 절차

## 행·열 선택

원본 PDF 89쪽의 순서입니다. 사용자가 값을 넣을 행 번호와 열 번호를 선택합니다.

## 값 입력

Field에 표에 넣을 값을 입력합니다.

## 인덱스 변환

선택한 번호에서 1을 빼서 리스트 위치로 바꿉니다.

## 변경 반영

선택한 DataCell의 내용을 바꾸고 표에 표시합니다.
:::

:::page{type="practice-checklist" id="ch11-check"}
# 원본 실습의 완료 확인

- [ ] 원본 Table의 입력과 과목 순서를 맞췄다.
- [ ] 행·열 번호에서 1을 빼는 이유를 설명했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch12-opening" chapter="12"}
# 입력 데이터를 차트와 저장으로 연결

## 12차시 · 원본 교재 예시로 배우기

### 학습 목표

- 선 그래프, 막대그래프, 산점도를 구분할 수 있다.
- 학생 자료와 공공데이터의 표·차트를 확인할 수 있다.
- 프로젝트 저장과 데이터 보관을 구분할 수 있다.

### 오늘의 시작

책의 다섯 값 선 그래프, 키·몸무게 산점도, 입력값 막대그래프를 사용합니다. 저장된 자료를 다시 열어 같은 값이 남아 있는지도 확인합니다.
:::

:::page{type="comparison" id="ch12-charts"}
# 표현 목적에 맞는 그래프

입력과 처리 결과를 나란히 비교해봅시다.

| 그래프 | 표현할 내용 | 축 확인 |
|---|---|---|
| 선 그래프 | 순서에 따른 값 변화 | 입력 순서와 수치 |
| 막대그래프 | 항목별 값 크기 | 항목과 수치 |
| 산점도 | 두 수치의 짝 | X의 값과 Y의 값 |
:::

:::page{type="practice-opening" id="ch12-practice-1" practice="012-1" practice-kind="원본 시각화 실습" platform="알고플로에서 실습하기"}
# 꺾은선 그래프 만들기

원본 PDF 97-99쪽 · 시각화 프로그램 1.

fld1부터 fld5까지 다섯 수치를 입력하고 그래프 그리기 버튼을 눌러봅시다. 책의 실행 화면에 있는 1·2·5·4·5를 사용하고 초기화 버튼의 역할도 확인합니다.

> [!TIP]
> 원본 그래프의 가로 위치는 입력 순서 0부터 4입니다.

- [ ] 다섯 Field와 Chart를 구성했다.
- [ ] 책의 입력값이 꺾은선으로 표시된다.
- [ ] 초기화 버튼을 확인했다.
:::

:::page{type="concept" id="ch12-line-screen" layout="basic"}
# 책의 선 그래프 화면

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

다섯 입력값 1, 2, 5, 4, 5와 가로 위치 0부터 4의 선 그래프가 보입니다.

::image{src="assets/source-20261006/line-chart.png" alt="다섯 입력값 1, 2, 5, 4, 5와 가로 위치 0부터 4의 선 그래프가 보입니다." ratio="856:467" width="text" caption="원본 PDF 99쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch12-practice-2" practice="012-2" practice-kind="원본 시각화 실습" platform="알고플로에서 실습하기"}
# 키·몸무게 산점도 만들기

원본 PDF 100-102쪽 · 시각화 프로그램 2.

두 Field에 키와 몸무게를 입력하고 버튼으로 Chart에 점을 추가해봅시다. 책의 실행 화면에 보이는 170·75, 180·82, 185·89를 대조합니다.

> [!TIP]
> 원본은 현재 값만 표시할지 누적할지 정하도록 안내합니다.

- [ ] 키와 몸무게를 서로 다른 입력창으로 받는다.
- [ ] 입력한 한 쌍이 점 하나로 표시된다.
- [ ] 누적한 세 쌍을 원본 화면과 비교했다.
:::

:::page{type="concept" id="ch12-scatter-screen" layout="basic"}
# 책의 키·몸무게 산점도

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

현재 입력 185와 89, 이전 입력을 포함한 세 점이 표시됩니다.

::image{src="assets/source-20261006/scatter-chart.png" alt="현재 입력 185와 89, 이전 입력을 포함한 세 점이 표시됩니다." ratio="904:464" width="text" caption="원본 PDF 102쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch12-practice-3" practice="012-3" practice-kind="원본 시각화 실습" platform="알고플로에서 실습하기"}
# 입력값 막대그래프 만들기

원본 PDF 103-105쪽 · 시각화 프로그램 3.

fld1의 값을 버튼으로 차례로 추가하여 막대그래프로 만들어봅시다. 책에 보이는 90·80·70의 세 막대를 비교합니다.

> [!TIP]
> 원본 설명처럼 누적할지 현재 자료만 보일지 정합니다.

- [ ] 입력창·버튼·Chart를 구성했다.
- [ ] 입력한 값을 막대로 표시했다.
- [ ] 90·80·70의 세 막대를 원본과 비교했다.
:::

:::page{type="concept" id="ch12-bar-screen" layout="basic"}
# 책의 입력값 막대그래프

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

90, 80, 70의 세 막대가 입력 순서대로 보입니다.

::image{src="assets/source-20261006/bar-chart.png" alt="90, 80, 70의 세 막대가 입력 순서대로 보입니다." ratio="480:545" width="half" caption="원본 PDF 105쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch12-practice-data" practice="012-4" practice-kind="원본 자료 활용" platform="알고플로에서 실습하기"}
# 학생 100명 자료 불러와 시각화하기

원본 PDF 106-109쪽 · 저장된 데이터 불러오기.

자료 버튼에서 책의 학생 100명 키·몸무게 자료를 불러와봅시다. 표에 표시할 항목을 고르고 키와 몸무게의 두 열을 산점도의 X·Y로 지정합니다.

> [!TIP]
> 원본 학생 자료를 수업 환경에서 제공받아 사용합니다.

- [ ] 학생 100명 자료를 선택했다.
- [ ] 표의 ID·키·몸무게 등 항목을 선택했다.
- [ ] 산점도에 연결할 두 열을 확인했다.
:::

:::page{type="step-process" id="ch12-loaded-data"}
# 저장된 자료 · 원본 불러오기 순서

## 자료 선택

원본 PDF 106-109쪽의 순서입니다. 자료 버튼에서 학생 100명의 키와 몸무게 자료를 선택합니다.

## 표 항목 선택

책의 ID·키·몸무게 또는 ID·성별·키·몸무게 구성을 살펴봅니다.

## 산점도 설정

X축과 Y축에 쓸 열을 직접 확인합니다. 원본 109쪽의 설명과 화면 축 범위를 대조합니다.
:::

:::page{type="concept" id="ch12-data-screen" layout="basic"}
# 원본 자료의 표시 항목 선택

## 원본 실습 화면

원본의 자료 항목 선택 메뉴입니다. 표시할 열을 선택하고 표와 그래프의 연결을 확인합니다.

::image{src="assets/source-20261010/data-column-select.png" alt="원본의 자료 항목 선택 메뉴입니다. 표시할 열을 선택하고 표와 그래프의 연결을 확인합니다." ratio="946:408" width="text" caption="원본 PDF 107쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch12-practice-school" practice="012-5" practice-kind="원본 자료 활용" platform="알고플로에서 실습하기"}
# 학교별 학생 수를 막대그래프로 표현

원본 PDF 110쪽 · 저장된 자료 활용 예시.

앞에서 불러온 같은 학생 자료를 사용해 학교별 학생 수를 막대그래프로 표시해봅시다. 원본처럼 고등학교와 중학교의 개수를 비교합니다.

> [!TIP]
> 앞에서 불러온 자료의 school 열을 사용합니다.

- [ ] 앞의 학생 자료를 그대로 사용했다.
- [ ] 학교 항목별 개수를 집계했다.
- [ ] 고등학교·중학교 막대를 비교했다.
:::

:::page{type="concept" id="ch12-school-screen" layout="basic"}
# 원본의 학교별 개수 막대그래프

## 원본 실습 화면

원본 학생 자료를 학교 구분별 개수로 표시한 화면입니다.

::image{src="assets/source-20261010/school-count-chart.png" alt="원본 학생 자료를 학교 구분별 개수로 표시한 화면입니다." ratio="1020:992" width="text" caption="원본 PDF 110쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch12-practice-api" practice="012-6" practice-kind="원본 API 실습" platform="알고플로에서 실습하기"}
# 자치구별 지하철역 정보 시각화

원본 PDF 111-117쪽 · 공공데이터 API 활용 예시.

원본의 “서울 교통공사 자치구별지하철역정보” 자료를 대상으로 합니다. 역개수·자치구·해당역(호선)을 tbl1에 표시하고 역 개수가 많은 상위 5개 자치구를 cht1에 나타내봅시다.

> [!TIP]
> 실제 실행에는 수업에서 확인한 API 주소와 인증 정보가 필요합니다. 원본 화면을 자신의 실행 결과로 제출하지 않습니다.

- [ ] 원본의 지하철역 자료 구조를 확인했다.
- [ ] 자치구와 역개수를 표·그래프에 연결했다.
- [ ] 상위 5개 자치구를 표시했다.
:::

:::page{type="step-process" id="ch12-api-steps"}
# 지하철역 API · 원본 실습 순서

## 자료와 구조 확인

원본 PDF 112-117쪽의 순서입니다. 원본에 명시된 자료에서 역개수·자치구·해당역(호선)의 위치를 확인합니다.

## 위젯 구성

btn1, tbl1, cht1을 구성합니다.

## 데이터 가져오기

수업에서 확인한 API로 데이터를 가져와 표와 막대그래프에 연결합니다.

## 상위 5개 표시

원본처럼 역 개수가 많은 자치구 다섯 개만 선택하여 표시합니다.
:::

:::page{type="concept" id="ch12-api-screen" layout="basic"}
# 원본의 상위 5개 자치구 결과

## 원본 실습 화면

원본 PDF 117쪽에 수록된 표와 그래프입니다. 자료를 가져와 자치구별 역 개수 상위 5개를 표시한 예시 결과를 살펴봅니다.

::image{src="assets/source-20261010/subway-top5-result.png" alt="원본 PDF 117쪽에 수록된 표와 그래프입니다. 자료를 가져와 자치구별 역 개수 상위 5개를 표시한 예시 결과를 살펴봅니다." ratio="980:587" width="text" caption="원본 PDF 117쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch12-practice-4" practice="012-7" practice-kind="원본 저장 실습" platform="알고플로에서 실습하기"}
# 입력받은 데이터 저장·불러오기

원본 PDF 118-127쪽 · 입력 데이터 저장 예시.

책의 fld1·fld2, tbl1, cht1, 두 버튼으로 화면을 구성해봅시다. 표 저장 설정 후 데이터를 추가하고 프로젝트를 저장합니다. 불러오기에서 같은 기록이 남아 있는지 확인합니다.

> [!TIP]
> 표 모양은 표 저장 설정 전에 정한다는 원본 안내를 확인합니다.

- [ ] 표 저장 설정을 확인했다.
- [ ] 입력한 표·차트 데이터와 프로젝트를 저장했다.
- [ ] 다시 불러와 같은 기록을 확인했다.
:::

:::page{type="step-process" id="ch12-save-process"}
# 저장·불러오기 확인 순서

## 표 구성과 저장 옵션 확인

먼저 행·열 구성을 정하고 책의 표 저장 옵션을 확인합니다. 원본 화면에서는 저장 설정 후 행·열 변경이 제한된다고 안내합니다.

## 데이터 추가 후 프로젝트 저장

추가한 행 수와 값 목록을 적고 프로젝트 이름을 정해 저장합니다.

## 불러온 뒤 비교

다시 실행하여 표 값과 차트 점을 비교합니다. 수업 도구의 실제 저장 동작을 확인한 뒤 완료를 판단합니다.
:::

:::page{type="concept" id="ch12-saved" layout="basic"}
# 다시 불러온 책의 프로젝트

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

불러온 프로젝트에 표와 산점도 기록이 함께 표시됩니다. 화면은 저장 동작을 설명하는 원본 예시입니다.

::image{src="assets/source-20261006/saved-project.png" alt="불러온 프로젝트에 표와 산점도 기록이 함께 표시됩니다. 화면은 저장 동작을 설명하는 원본 예시입니다." ratio="744:1282" width="half" caption="원본 PDF 127쪽의 실습 화면"}
:::

:::page{type="practice-checklist" id="ch12-check"}
# 원본 실습의 완료 확인

- [ ] 책의 선·산점도·막대그래프를 따라 만들었다.
- [ ] 학생 자료의 표시 항목과 학교별 개수를 확인했다.
- [ ] API 실습은 실제 실행과 원본 결과 열람을 구분했다.
- [ ] 저장·불러오기에서 입력 데이터를 확인했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch13-opening" chapter="13"}
# Matplotlib 그래프 만들기

## 13차시 · 원본 교재 예시로 배우기

### 학습 목표

- Figure와 Axes의 역할을 구분할 수 있다.
- 그래프 제목과 축을 함수로 설정할 수 있다.
- 같은 데이터로 결과 이미지와 코드를 대조할 수 있다.

### 오늘의 시작

원본의 배열, 범위, 마커, 나란한 막대, 산점도 예시를 짧은 실행 코드로 정리합니다. 원본 이미지가 코드와 다른 경우 새 실행 결과로 교체합니다.
:::

:::page{type="concept" id="ch13-axes" layout="basic"}
# 그릴 판과 그리는 영역

## Figure와 Axes

plt.subplots는 Figure와 Axes를 함께 만듭니다. Figure는 전체 그림이고 Axes는 실제 데이터를 그리는 영역입니다. 먼저 생성한 뒤 ax.plot처럼 사용합니다.

## Python 예제와 수업 GUI

이 차시 코드는 독립 Python 예제입니다. 책의 fch.MatplotlibChart는 수업 GUI에 그림을 연결하는 부분이며, 단독 예제에 정의 없이 복사하지 않습니다. 생성한 Figure를 GUI에 연결할 때는 해당 수업 도구의 환경을 확인합니다.
:::

:::page{type="practice-opening" id="ch13-practice-1" practice="013-1" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 1 · 배열 한 개

원본 PDF 131-132쪽 · 실습 013-1.

책의 [1, 2, 3, 4, 5] 배열을 선으로 그려봅시다. 하나의 배열을 전달했을 때 X축이 0부터 4까지의 위치가 되는지 확인합니다.

> [!TIP]
> 원본의 Chart 구성과 생성된 Axes 역할을 연결합니다.

- [ ] 책의 배열을 그대로 사용했다.
- [ ] 배열 하나를 plot에 전달했다.
- [ ] X 위치 0부터 4를 확인했다.
:::

:::page{type="concept" id="ch13-one-array" layout="basic"}
# 실습 1 · 배열 한 개의 그래프

## 원본 예시 따라 실행하기

원본 PDF 131-132쪽의 자료와 설정을 사용합니다.

```python
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(8, 5))
ax.plot([1, 2, 3, 4, 5])
fig.tight_layout()
plt.show()
```

::image{src="assets/source-20261006/plot-one.png" alt="실습 1 · 배열 한 개의 그래프 코드 실행 결과" ratio="8:5" width="text" role="result" caption="원본 PDF 131-132쪽의 데이터를 사용한 실제 코드 실행 결과"}
:::

:::page{type="practice-opening" id="ch13-practice-two" practice="013-2" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 2 · X·Y 배열

원본 PDF 133쪽 · 실습 013-2.

책의 a = [15, 25, 35, 45, 55], b = [5, 10, 15, 20, 25]를 X와 Y로 지정해봅시다. 두 배열의 같은 위치 값이 한 점으로 연결됩니다.

> [!TIP]
> 두 배열의 길이와 값의 짝을 확인합니다.

- [ ] a와 b 배열을 책과 같이 정했다.
- [ ] a는 X, b는 Y로 연결했다.
- [ ] 다섯 점의 위치를 원본과 비교했다.
:::

:::page{type="concept" id="ch13-two-arrays" layout="basic"}
# 실습 2 · X·Y 배열 지정

## 원본 예시 따라 실행하기

원본 PDF 133쪽의 자료와 설정을 사용합니다.

```python
import matplotlib.pyplot as plt

a = [15, 25, 35, 45, 55]
b = [5, 10, 15, 20, 25]
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(a, b)
fig.tight_layout()
plt.show()
```

::image{src="assets/source-20261006/plot-two.png" alt="실습 2 · X·Y 배열 지정 코드 실행 결과" ratio="8:5" width="text" role="result" caption="원본 PDF 133쪽의 데이터를 사용한 실제 코드 실행 결과"}
:::

:::page{type="practice-opening" id="ch13-practice-2" practice="013-3" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 3 · 표시 범위

원본 PDF 134쪽 · 실습 013-3.

X는 [1, 2, 3, 4, 5], Y는 [5, 10, 15, 20, 25]로 정합니다. 책처럼 b-+ 모양과 axis([0, 10, 0, 25])를 적용해봅시다.

> [!TIP]
> 값을 바꾸는 것과 표시 범위를 바꾸는 것을 구분합니다.

- [ ] 원본의 X·Y 값을 사용했다.
- [ ] 파란 선과 더하기 마커를 지정했다.
- [ ] X 0-10, Y 0-25 범위를 확인했다.
:::

:::page{type="concept" id="ch13-range" layout="basic"}
# 실습 3 · 선 모양과 표시 범위

## 원본 예시 따라 실행하기

원본 PDF 134쪽의 자료와 설정을 사용합니다.

```python
import matplotlib.pyplot as plt

a = [1, 2, 3, 4, 5]
b = [5, 10, 15, 20, 25]
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(a, b, "b-+", clip_on=False)
ax.axis([0, 10, 0, 25])
fig.tight_layout()
plt.show()
```

::image{src="assets/source-20261006/plot-range.png" alt="실습 3 · 선 모양과 표시 범위 코드 실행 결과" ratio="8:5" width="text" role="result" caption="원본 PDF 134쪽의 데이터를 사용한 실제 코드 실행 결과"}
:::

:::page{type="practice-opening" id="ch13-practice-colors" practice="013-4" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 4 · 모양과 색

원본 PDF 136쪽 · 실습 013-4.

책의 같은 X·Y 배열에 ro를 적용해 빨간 점으로 표시해봅시다. 원본 안내의 r-o도 비교하여 점만 그리는 경우와 선이 이어지는 경우를 구분합니다.

> [!TIP]
> 원본 코드 ro와 연결선 그림의 차이는 실행 결과를 기준으로 바로잡았습니다.

- [ ] 원본 배열을 유지했다.
- [ ] ro가 빨간 점임을 확인했다.
- [ ] r-o와의 선 표시 차이를 설명했다.
:::

:::page{type="concept" id="ch13-markers" layout="basic"}
# 실습 4 · 빨간 점과 설명

## 원본 예시 따라 실행하기

원본 PDF 136-138쪽의 자료와 설정을 사용합니다.

```python
import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [5, 10, 15, 20, 25]
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(x, y, "ro", clip_on=False)
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("hello")
ax.text(3, 5, "12/19")
ax.axis([0, 10, 0, 25])
fig.tight_layout()
plt.show()
```

::image{src="assets/source-20261006/plot-markers.png" alt="실습 4 · 빨간 점과 설명 코드 실행 결과" ratio="8:5" width="text" role="result" caption="원본 PDF 136-138쪽의 데이터를 사용한 실제 코드 실행 결과"}
:::

:::page{type="practice-opening" id="ch13-practice-labels" practice="013-5" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 5 · 제목과 설명

원본 PDF 137-138쪽 · 실습 013-5.

원본에서 같은 그래프에 지정한 x·y 축 이름, hello 제목, 좌표 (3, 5)의 12/19 설명을 확인해봅시다. 앞 실습의 코드와 데이터를 그대로 사용합니다.

> [!TIP]
> 원본 실습 4와 5의 코드는 같고, 이번에는 설명 글자에 집중합니다.

- [ ] x·y 축 이름을 확인했다.
- [ ] hello 제목을 확인했다.
- [ ] (3, 5)의 12/19 설명을 확인했다.
:::

:::page{type="concept" id="ch13-labels-screen" layout="basic"}
# 원본 실습의 제목·축·좌표 설명

## 원본 실습 화면

원본 136·138쪽의 동일한 코드로 만든 수정 결과입니다. 제목 hello, 축 x·y와 좌표 설명 12/19를 확인합니다.

::image{src="assets/source-20261006/plot-markers.png" alt="원본 136·138쪽의 동일한 코드로 만든 수정 결과입니다. 제목 hello, 축 x·y와 좌표 설명 12/19를 확인합니다." ratio="1920:1200" width="text" caption="원본 136·138쪽 코드를 오류 수정하여 실행한 결과"}
:::

:::page{type="practice-opening" id="ch13-practice-3" practice="013-6" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 6 · 막대그래프 1

원본 PDF 140쪽 · 원본 실습 014-6.

책의 [1, 2, 4, 8, 16, 32, 64, 128]을 막대로 그려봅시다. range(len(a))로 X 위치를 만들고 각 높이를 확인합니다.

> [!TIP]
> 원본의 실습 번호와 제목 오기는 이 교재에서 차시 순서에 맞게 정리했습니다.

- [ ] 2의 거듭제곱 배열을 사용했다.
- [ ] 여덟 값의 막대를 그렸다.
- [ ] 막대 높이와 배열 값을 비교했다.
:::

:::page{type="concept" id="ch13-bars" layout="basic"}
# 실습 6 · 막대그래프 1

## 원본 예시 따라 실행하기

원본 PDF 140쪽의 자료와 설정을 사용합니다.

```python
import matplotlib.pyplot as plt

a = [1, 2, 4, 8, 16, 32, 64, 128]
fig, ax = plt.subplots(figsize=(8, 5))
ax.bar(range(len(a)), a)
fig.tight_layout()
plt.show()
```

::image{src="assets/source-20261006/plot-bars.png" alt="실습 6 · 막대그래프 1 코드 실행 결과" ratio="8:5" width="text" role="result" caption="원본 PDF 140쪽의 데이터를 사용한 실제 코드 실행 결과"}
:::

:::page{type="practice-opening" id="ch13-practice-grouped" practice="013-7" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 7 · 막대그래프 2

원본 PDF 141-142쪽 · 원본 실습 014-7.

one부터 five까지의 항목과 책의 value_a·value_b 배열을 사용해봅시다. 원본 create_x 함수로 두 막대의 위치를 만들고 중간 위치에 항목 이름을 표시합니다.

> [!TIP]
> 원본의 t, w, n, d 위치 계산을 유지합니다.

- [ ] 원본의 두 값 배열을 유지했다.
- [ ] create_x로 두 막대를 나란히 배치했다.
- [ ] 중간 위치에 one부터 five까지 표시했다.
:::

:::page{type="concept" id="ch13-grouped" layout="basic"}
# 실습 7 · 나란한 막대그래프

## 원본 예시 따라 실행하기

원본 PDF 141-142쪽의 자료와 설정을 사용합니다.

```python
import matplotlib.pyplot as plt

topics = ["one", "two", "three", "four", "five"]
value_a = [35, 80, 84, 83, 50]
value_b = [73, 80, 77, 40, 86]

def create_x(t, w, n, d):
    return [t * x + w * n for x in range(d)]

value_a_x = create_x(2, 0.8, 1, 5)
value_b_x = create_x(2, 0.8, 2, 5)
fig, ax = plt.subplots(figsize=(8, 5))
ax.bar(value_a_x, value_a)
ax.bar(value_b_x, value_b)
middle_x = [(a + b) / 2
            for a, b in zip(value_a_x, value_b_x)]
ax.set_xticks(middle_x)
ax.set_xticklabels(topics)
fig.tight_layout()
plt.show()
```

::image{src="assets/source-20261006/plot-grouped.png" alt="실습 7 · 나란한 막대그래프 코드 실행 결과" ratio="8:5" width="text" role="result" caption="원본 PDF 141-142쪽의 데이터를 사용한 실제 코드 실행 결과"}
:::

:::page{type="practice-opening" id="ch13-practice-4" practice="013-8" practice-kind="원본 Matplotlib" platform="알고플로에서 실습하기"}
# Matplotlib 실습 8 · 산점도

원본 PDF 144-145쪽 · 원본 실습 014-8.

책의 시드 20211206, X 범위 1.1부터 100.0 미만, 간격 5.0을 유지해봅시다. X의 1.5배에 난수를 더한 Y로 산점도를 만들고 축 이름을 함수 호출로 설정합니다.

> [!TIP]
> 원본의 seed·rand 설명과 축 이름 대입 오류만 바로잡았습니다.

- [ ] 책의 시드와 X 범위를 사용했다.
- [ ] 책의 Y 생성식을 사용했다.
- [ ] 축 이름·random 범례·제목을 확인했다.
:::

:::page{type="concept" id="ch13-scatter" layout="basic"}
# 실습 8 · 산점도

## 원본 예시 따라 실행하기

원본 PDF 145쪽의 자료와 설정을 사용합니다. 축 제목은 함수 호출로 지정하여 원본의 대입 오류를 고쳤습니다.

```python
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(20211206)
x = np.arange(1.1, 100.0, 5.0)
y = x * 1.5 + np.random.rand(20) * 50
fig, ax = plt.subplots(figsize=(8, 5))
ax.scatter(x, y, c="red", alpha=0.5, label="random")
ax.set_xlabel("X축 제목")
ax.set_ylabel("Y축 제목")
ax.legend(loc="upper left")
ax.set_title("random")
fig.tight_layout()
plt.show()
```

::image{src="assets/source-20261006/plot-scatter.png" alt="실습 8 · 산점도 코드 실행 결과" ratio="8:5" width="text" role="result" caption="원본 PDF 145쪽의 데이터를 사용한 실제 코드 실행 결과"}
:::

:::page{type="concept" id="ch13-fix" layout="basic"}
# 원본 그래프에서 바로잡은 코드

## 원본 PDF 136·138쪽

ro는 빨간 점입니다. 코드가 ro일 때 점을 이어 그린 그림은 코드와 다르므로 실제 실행 그림을 사용했습니다.

## 원본 PDF 144-145쪽

seed는 난수 생성기의 상태를 정합니다. 축 이름은 set_xlabel("X축 제목"), set_ylabel("Y축 제목")처럼 함수로 설정합니다. 생성 데이터는 원본 예제이며 실제 관측 자료가 아닙니다.
:::

:::page{type="practice-checklist" id="ch13-check"}
# 원본 실습의 완료 확인

- [ ] 원본 여덟 Matplotlib 실습을 대조했다.
- [ ] 배열·범위·마커·글자·막대 위치를 확인했다.
- [ ] 산점도의 시드와 축 이름을 확인했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch14-opening" chapter="14"}
# Pandas로 데이터 정리하기

## 14차시 · 원본 교재 예시로 배우기

### 학습 목표

- Series와 DataFrame의 차이를 설명할 수 있다.
- 인덱스, 값, 열 이름을 구분할 수 있다.
- 요일별 열과 학생 정보 표를 만들 수 있다.

### 오늘의 시작

책의 딕셔너리, 혼합 자료 리스트, 학생 정보 표를 그대로 사용합니다. 출력은 수업 전용 message 대신 독립 실행 가능한 print로 바꿉니다.
:::

:::page{type="comparison" id="ch14-formats"}
# 데이터를 보관하는 형식

책 147쪽의 제목은 데이터 파일 형식으로 바로잡았습니다. 이 차시의 필수 실습은 파일 없이 직접 만든 자료로 진행합니다.

| 형식 | 특징 |
|---|---|
| CSV | 구분자로 항목을 나누는 텍스트 자료 |
| Excel | 시트의 행과 열에 정리한 자료 |
| JSON | 키와 값 등의 구조로 표현한 자료 |
:::

:::page{type="comparison" id="ch14-structure"}
# Series와 DataFrame 비교

입력과 처리 결과를 나란히 비교해봅시다.

| 구분 | Series | DataFrame |
|---|---|---|
| 차원 | 1차원 | 2차원 |
| 구조 | 인덱스와 값의 대응 | 행과 열로 이루어진 표 |
| 라벨 | index | index와 columns |
:::

:::page{type="practice-opening" id="ch14-practice-1" practice="014-1" practice-kind="본문 예시 따라하기" platform="알고플로에서 실습하기"}
# Series · 원본 딕셔너리와 리스트

원본 PDF 148-149쪽 · Pandas 본문 예시.

one·two·three 딕셔너리와 [2022-01-01, 2.14, song, 1000, True] 리스트로 Series를 만들어봅시다. 원본처럼 Series, index, values를 각각 확인합니다.

> [!TIP]
> 독립 Python 실행에서는 원본 message를 print로 바꿉니다.

- [ ] 원본 딕셔너리와 리스트를 사용했다.
- [ ] Series 전체를 출력했다.
- [ ] index와 values를 구분했다.
:::

:::page{type="concept" id="ch14-series" layout="basic"}
# 딕셔너리를 Series로 변환

## 원본 예시 따라 실행하기

원본 PDF 148쪽의 자료를 그대로 사용합니다.

```python
import pandas as pd

dict_data = {"one": 1, "two": 2, "three": 3}
ser = pd.Series(dict_data)
print(ser)
```

```output
one      1
two      2
three    3
dtype: int64
```
:::

:::page{type="concept" id="ch14-mixed" layout="basic"}
# 리스트를 Series로 변환

## 원본 예시 따라 실행하기

원본 PDF 149쪽의 자료를 그대로 사용합니다.

```python
import pandas as pd

list_data = ["2022-01-01", 2.14, "song", 1000, True]
sr = pd.Series(list_data)
print(sr)
print(sr.index)
print(sr.values)
```

```output
0    2022-01-01
1          2.14
2          song
3          1000
4          True
dtype: object
RangeIndex(start=0, stop=5, step=1)
['2022-01-01' 2.14 'song' 1000 True]
```
:::

:::page{type="practice-opening" id="ch14-practice-dict" practice="014-2" practice-kind="본문 예시 따라하기" platform="알고플로에서 실습하기"}
# DataFrame · 요일별 열 만들기

원본 PDF 150쪽 · Pandas 본문 예시.

원본의 mon부터 sun까지 딕셔너리를 DataFrame으로 바꿔봅시다. 딕셔너리의 키가 열 이름, 각 리스트가 해당 열의 값이 되는지 확인합니다.

> [!TIP]
> 원본의 tue 배열 [2, 9, 6, 23]을 그대로 유지합니다. 달력 날짜로 재해석하지 않습니다.

- [ ] 원본의 일곱 열 데이터를 사용했다.
- [ ] DataFrame으로 변환했다.
- [ ] 열 이름과 각 행 값을 확인했다.
:::

:::page{type="concept" id="ch14-dict-frame-code" layout="basic"}
# 요일별 열의 DataFrame

## 원본 예시 따라 실행하기

원본 PDF 150쪽의 자료를 그대로 사용합니다.

```python
import pandas as pd

dict_data = {
    "mon": [1, 8, 15, 22],
    "tue": [2, 9, 6, 23],
    "wed": [3, 10, 17, 24],
    "thu": [4, 11, 18, 25],
    "fri": [5, 12, 19, 26],
    "sat": [6, 13, 20, 27],
    "sun": [7, 14, 21, 28],
}
df = pd.DataFrame(dict_data)
print(type(df))
print(df)
```

```output
<class 'pandas.core.frame.DataFrame'>
   mon  tue  wed  thu  fri  sat  sun
0    1    2    3    4    5    6    7
1    8    9   10   11   12   13   14
2   15    6   17   18   19   20   21
3   22   23   24   25   26   27   28
```
:::

:::page{type="practice-opening" id="ch14-practice-2" practice="014-3" practice-kind="본문 예시 따라하기" platform="알고플로에서 실습하기"}
# DataFrame · 행·열 이름 지정과 변경

원본 PDF 151쪽 · Pandas 본문 예시.

현아 [15, 여, 중2]와 태민 [17, 남, 고1] 자료를 사용해봅시다. 행·열 이름을 확인하고 책처럼 행은 학생1·학생2, 열은 연령·남녀·학년으로 바꿉니다.

> [!TIP]
> 본문의 유상 표기는 코드와 같은 태민으로 고쳤습니다.

- [ ] 현아·태민의 원본 자료를 사용했다.
- [ ] 행 이름과 열 이름을 구분했다.
- [ ] 학생1·학생2와 연령·남녀·학년으로 변경했다.
:::

:::page{type="concept" id="ch14-dataframe" layout="basic"}
# 현아·태민 자료의 DataFrame

## 원본 예시 따라 실행하기

원본 PDF 151쪽의 자료를 그대로 사용합니다. 본문의 이름 표기를 코드와 같은 태민으로 맞췄습니다.

```python
import pandas as pd

df = pd.DataFrame(
    [[15, "여", "중2"], [17, "남", "고1"]],
    index=["현아", "태민"],
    columns=["나이", "성별", "학년"],
)
print(df)
print(df.index)
print(df.columns)
```

```output
    나이 성별  학년
현아  15  여  중2
태민  17  남  고1
Index(['현아', '태민'], dtype='object')
Index(['나이', '성별', '학년'], dtype='object')
```
:::

:::page{type="concept" id="ch14-table-result" layout="basic"}
# 실행한 DataFrame을 표로 확인하기

## 예시 확인하기

앞의 코드가 만든 실제 DataFrame을 표 이미지로 출력했습니다. 행 이름과 열 이름은 데이터 값과 구분됩니다.

::image{src="assets/source-20261006/pandas-table.png" alt="현아 15 여 중2와 태민 17 남 고1의 DataFrame" ratio="8:5" width="text" caption="실행한 DataFrame으로 제작한 학습용 표"}
:::

:::page{type="concept" id="ch14-rename" layout="basic"}
# 이름 변경과 값 변경 구분하기

## 인덱스·열 이름 변경

df.index를 학생1·학생2로 바꾸면 행 이름이 달라집니다. df.columns를 연령·남녀·학년으로 바꾸면 열 이름이 달라집니다.

## 데이터는 유지

이름을 바꿔도 15, 17 같은 값이 저절로 바뀌지 않습니다. 라벨 변경과 값 수정을 구분하여 검증합니다.
:::

:::page{type="concept" id="ch14-rename-code" layout="basic"}
# DataFrame 행·열 이름 변경

## 원본 예시 따라 실행하기

원본 PDF 151쪽의 자료를 그대로 사용합니다.

```python
import pandas as pd

df = pd.DataFrame(
    [[15, "여", "중2"], [17, "남", "고1"]],
    index=["현아", "태민"],
    columns=["나이", "성별", "학년"],
)
df.index = ["학생1", "학생2"]
df.columns = ["연령", "남녀", "학년"]
print(df)
print(df.index)
print(df.columns)
```

```output
     연령 남녀  학년
학생1  15  여  중2
학생2  17  남  고1
Index(['학생1', '학생2'], dtype='object')
Index(['연령', '남녀', '학년'], dtype='object')
```
:::

:::page{type="practice-checklist" id="ch14-check"}
# 원본 실습의 완료 확인

- [ ] 원본 Series 자료의 index·values를 구분했다.
- [ ] 요일별 열과 현아·태민 DataFrame을 만들었다.
- [ ] 원본의 행·열 이름 변경을 확인했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch15-opening" chapter="15"}
# 코코봇과 앱 연결하기

## 15차시 · 원본 교재 예시로 배우기

### 학습 목표

- 입력, 클릭, 명령, 동작의 흐름을 설명할 수 있다.
- 거리 입력과 각도 입력을 구분할 수 있다.
- 장비 연결과 실제 동작 확인을 구분해 기록할 수 있다.

### 오늘의 시작

책의 세 버튼 예시를 먼저 읽고, 거리와 각도를 입력하는 예시로 확장합니다. 실제 장비와 연결 환경이 없으면 명령 설계와 입력 검증까지 진행합니다.
:::

:::page{type="concept" id="ch15-robot-flow" layout="basic"}
# 화면의 값을 실제 명령으로 연결

## 기본 흐름

거리나 각도를 입력하고 버튼을 누르면 프로그램이 명령을 전달합니다. 실제 코코봇의 움직임을 관찰하여 요청한 방향과 값에 대응하는지 확인합니다.

## 환경 확인

코코봇 함수 이름, 연결 방식, 거리 단위와 허용 범위는 사용하는 장비·수업 환경에서 확인합니다. 책의 이동 값 100을 근거 없이 100cm로 바꾸지 않습니다.
:::

:::page{type="concept" id="ch15-buttons" layout="basic"}
# 책의 기본 이동·회전 버튼

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

앞으로 100 이동, 왼쪽 90 회전, 오른쪽 90 회전의 세 버튼이 보입니다.

::image{src="assets/source-20261006/cocobot-buttons.png" alt="앞으로 100 이동, 왼쪽 90 회전, 오른쪽 90 회전의 세 버튼이 보입니다." ratio="631:309" width="half" caption="원본 PDF 153쪽의 실습 화면"}
:::

:::page{type="practice-opening" id="ch15-practice-1" practice="015-1" practice-kind="원본 코코봇 실습" platform="알고플로에서 실습하기"}
# 코코봇 이동·회전 시켜보기

원본 PDF 153-154쪽 · 코코봇 프로그램 예시.

책의 세 버튼으로 앞으로 이동, 왼쪽 90도 회전, 오른쪽 90도 회전을 실행하는 프로그램을 설계해봅시다. 실제 동작은 수업의 장비 연결 환경에서 확인합니다.

> [!TIP]
> 이동 값 100의 단위는 장비 환경에서 확인합니다.

- [ ] 세 버튼에 책의 역할을 지정했다.
- [ ] 이동과 양쪽 회전을 각각 연결했다.
- [ ] 실행 또는 미실행 상태를 구분했다.
:::

:::page{type="concept" id="ch15-fields" layout="basic"}
# 거리와 각도를 받는 UI

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

fld1 이동거리와 fld2 회전각도, 이동·왼쪽 회전·오른쪽 회전 버튼이 분리되어 있습니다.

::image{src="assets/source-20261006/cocobot-fields.png" alt="fld1 이동거리와 fld2 회전각도, 이동·왼쪽 회전·오른쪽 회전 버튼이 분리되어 있습니다." ratio="741:652" width="text" caption="원본 PDF 155쪽의 실습 화면"}
:::

:::page{type="comparison" id="ch15-event-map"}
# 입력값과 버튼 매칭

입력과 처리 결과를 나란히 비교해봅시다.

| 버튼 | 읽을 입력 | 명령 역할 |
|---|---|---|
| 앞으로 이동 | fld1 거리 | 앞으로 이동 |
| 왼쪽 회전 | fld2 각도 | 왼쪽 회전 |
| 오른쪽 회전 | fld2 각도 | 오른쪽 회전 |
:::

:::page{type="practice-opening" id="ch15-practice-2" practice="015-2" practice-kind="원본 코코봇 실습" platform="알고플로에서 실습하기"}
# 입력받은 거리·각도로 코코봇 움직이기

원본 PDF 155-157쪽 · 코코봇 프로그램 예시.

fld1은 이동거리, fld2는 회전각도로 구성해봅시다. 책의 화면처럼 이동거리 100과 회전각도 90을 입력하고 각 버튼이 해당 입력을 읽도록 설정합니다.

> [!TIP]
> 책에 없는 코코봇 함수를 만들어 넣지 않고 수업에서 제공한 명령을 사용합니다.

- [ ] 거리와 각도 입력창을 구분했다.
- [ ] 이동 버튼은 거리 값을 읽는다.
- [ ] 회전 버튼은 각도 값을 읽는다.
:::

:::page{type="step-process" id="ch15-request"}
# 코코봇 · 원본 위젯 역할 설정

## 프로젝트 정보

원본 PDF 154-156쪽의 순서입니다. 원본처럼 코코봇 이동과 회전 기능을 프로젝트 설명에 적습니다.

## 입력창 역할

fld1은 이동거리, fld2는 회전각도로 역할을 정합니다.

## 버튼 역할

앞으로 이동, 왼쪽 회전, 오른쪽 회전의 세 역할을 각 버튼에 적습니다.

## 환경 연결

실제 수업에서 제공한 명령과 장비 연결을 확인하고 실행합니다.
:::

:::page{type="concept" id="ch15-inputs" layout="basic"}
# 책의 거리·각도 입력 상태

## 예시 확인하기

원본 교재에 실린 화면입니다. 화면에 보이는 입력값, 위젯 이름과 결과를 함께 읽어봅시다.

이동거리에 100, 회전각도에 90을 입력한 상태입니다. 이 캡처만으로 실제 코코봇 동작이 확인되는 것은 아닙니다.

::image{src="assets/source-20261006/cocobot-input.png" alt="이동거리에 100, 회전각도에 90을 입력한 상태입니다. 이 캡처만으로 실제 코코봇 동작이 확인되는 것은 아닙니다." ratio="582:514" width="half" caption="원본 PDF 157쪽의 실습 화면"}
:::

:::page{type="step-process" id="ch15-verify"}
# 명령과 실제 동작 확인하기

## 연결 상태 확인

수업 도구에서 장비 연결과 명령 함수를 확인합니다.

## 입력과 전달값 확인

거리·각도 입력창을 구분하고 실제 전달되는 값과 단위를 기록합니다.

## 한 기능씩 관찰

이동과 양쪽 회전을 따로 실행합니다. 명령을 보냈다는 기록과 실제 움직임을 관찰한 기록을 구분합니다.
:::

:::page{type="practice-checklist" id="ch15-check"}
# 원본 실습의 완료 확인

- [ ] 책의 이동·양쪽 회전 버튼을 설계했다.
- [ ] 거리 100·각도 90 입력과 버튼을 맞췄다.
- [ ] 장비 실행 여부를 실제로 구분했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::

:::page{type="chapter-opening" id="ch16-opening" chapter="16"}
# 앱 개선과 결과 발표

## 16차시 · 원본 교재 예시로 배우기

### 학습 목표

- 책의 예시를 골라 작은 프로젝트로 완성할 수 있다.
- 문제를 재현하고 수정 결과를 검증할 수 있다.
- AI 도움과 직접 확인한 내용을 구분해 발표할 수 있다.

### 오늘의 시작

원본 93-94쪽 자율 프로젝트의 아이디어와 UI 설계를 따라 작성합니다. 앞서 배운 위젯으로 프로그램을 만들고 동작 결과를 설명합니다.
:::

:::page{type="concept" id="ch16-projects" layout="basic"}
# 자율 프로젝트 · 원본 작성 양식

## 원본 PDF 93쪽

만들고 싶은 프로그램의 아이디어를 작성합니다. 목적과 필요한 입력, 보여줄 결과를 정리합니다.

## 원본 PDF 94쪽

UI 설계를 작성합니다. 필요한 위젯을 배치하고 이름과 역할, 버튼을 클릭했을 때 할 일을 적습니다.
:::

:::page{type="practice-opening" id="ch16-practice-1" practice="016-1" practice-kind="원본 실습" platform="알고플로에서 실습하기"}
# 원하는 프로그램을 자유롭게 작성하기

원본 PDF 93-94쪽 · 실습 009-8.

원본 자율 프로젝트 활동을 따라 프로그램 아이디어와 UI 설계를 작성해봅시다. 앞에서 배운 위젯으로 화면을 구성하고 버튼 이벤트를 정한 뒤 실행 결과를 확인합니다.

> [!TIP]
> 앞선 원본 실습의 위젯과 기능을 활용해 UI를 설계합니다.

- [ ] 프로그램 아이디어를 적었다.
- [ ] 원본 양식처럼 UI를 설계했다.
- [ ] 생성한 프로그램의 동작을 확인했다.
:::

:::page{type="step-process" id="ch16-procedure"}
# 작게 만들고 검증하기

## 성공 기준 정하기

어떤 입력을 넣었을 때 어떤 결과가 보여야 하는지 적습니다.

## 실행 결과 확인

직접 값을 넣고 결과를 기록합니다. 설명만 보고 통과로 표시하지 않습니다.

## 오류 하나 수정

문제 상황, 입력, 예상 결과, 실제 결과를 포함해 수정 요청합니다.

## 다시 확인

수정한 기능과 이전에 정상 동작하던 기능을 다시 실행합니다.
:::

:::page{type="concept" id="ch16-fix" layout="basic"}
# 자율 프로젝트의 입력과 동작 확인

## 원본 설계와 대조

입력창·버튼·결과 위젯의 역할이 자신이 적은 아이디어와 같은지 확인합니다.

## 확인 결과 정리

실행 화면과 확인한 동작을 남깁니다.
:::

:::page{type="concept" id="ch16-evidence" layout="basic"}
# 결과 이미지를 정직하게 기록하기

## 직접 만든 결과

자기 앱의 실제 입력과 결과가 같이 보이게 캡처합니다. 민감한 정보와 인증키를 빼고, 이전 버전 이미지가 남아 있지 않은지 확인합니다.

## 교재 그림과 구분

앞 차시의 원본 캡처는 학습 자료입니다. 그것을 자신의 완성 앱이나 직접 실행한 증거로 제출하지 않습니다. 오류 수정 전과 후는 같은 입력으로 비교합니다.
:::

:::page{type="concept" id="ch16-portfolio" layout="basic"}
# 포트폴리오에 담을 내용

## 기획과 구현

앱 이름, 사용자, 해결할 문제를 적습니다. 입력, 처리, 출력 설계와 주요 위젯 역할을 넣습니다.

## 검증과 개선

실행 가능한 프로젝트, 정상 입력 결과, 예외 입력 결과, 수정 요청과 재검증 기록을 남깁니다. 장비가 필요한 기능은 실제 실행 여부를 표시합니다.
:::

:::page{type="practice-checklist" id="ch16-check"}
# 원본 실습의 완료 확인

- [ ] 원본 자율 프로젝트의 아이디어·UI를 작성했다.
- [ ] 위젯 역할·이벤트·실행 결과를 대조했다.

> [!KEY_POINT]
> 책의 입력·동작·결과를 기준으로 직접 확인한 내용을 기록합니다.
:::
