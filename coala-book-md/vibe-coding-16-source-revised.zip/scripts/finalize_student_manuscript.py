"""Assemble the learner edition while preserving its exercises and code."""
from pathlib import Path
import json
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]
BOOK = ROOT / 'coala-book-md/vibe-coding-16'
RESTRUCTURE = BOOK / 'no-pandas-restructure.json'

GUIDE = ''':::page{type="concept" id="book-guide" layout="basic"}
# 이 교재를 사용하는 방법

## 개념을 익히고 실습하기

16차시에 걸쳐 AI 활용, 앱 설계, 프로그래밍, 데이터 시각화를 배웁니다. 각 차시의 학습 목표를 읽고 실습을 진행합니다.

## 입력·동작·결과 확인

실습의 조건과 위젯 이름을 먼저 읽습니다. 예시 값을 입력하고 실행 결과가 예상한 동작과 일치하는지 확인합니다. 입력값이 정해져 있지 않은 과제에서는 직접 값을 정합니다.

## 코드와 실행 화면

코드를 실행하면서 데이터와 처리 순서를 살펴봅니다. 예시 화면의 입력값과 결과를 읽고, 자신의 실행 화면과 확인한 내용을 기록합니다.

## 실습 준비와 차트 코드

알고플로 실습은 교사가 안내한 접속 주소와 계정으로 진행합니다. 위젯을 배치하고 버튼의 역할을 작성한 뒤 앱 화면에서 실행합니다.

12·13차시는 디자이너에서 만든 cht1에 그래프를 그립니다. 자동으로 생성된 fig_cht1·ax_cht1을 유지하고 예제의 그리기 부분을 앱의 시작 처리나 버튼 이벤트에 적용합니다. 수정 후 같은 화면에서 차트가 갱신되는지 확인합니다. 함께 제공한 실습 앱으로 입력과 버튼 동작을 다시 점검할 수 있습니다.
:::
'''

old = (BOOK / 'book.md').read_text(encoding='utf-8')
baseline = old
front = old.split('---', 2)[1]
front = re.sub(r'^subtitle:.*$', 'subtitle: 16차시 · 개념과 실습', front, flags=re.M)
chapters = []
for n in range(1, 17):
    text = (BOOK / f'ch{n:02d}.md').read_text(encoding='utf-8')
    chapters.append(text[text.index(':::page'):].strip())
new = '---' + front + '---\n\n' + GUIDE + '\n' + '\n\n'.join(chapters) + '\n'

def fences(text, language):
    return re.findall(r'^```' + language + r'\s*\n(.*?)^```\s*$', text, re.M | re.S)

revision = json.loads(RESTRUCTURE.read_text(encoding='utf-8'))
code_specs = json.loads((BOOK / 'code-specs.json').read_text(encoding='utf-8'))
assert [t.rstrip() for t in fences(new, 'python')] == [item['code'].rstrip() for item in code_specs], 'Chapter code must match the current reviewed code specification'
assert len(fences(new, 'output')) == 0

flow_map = BOOK / 'flow-source-map.json'
if flow_map.exists():
    expected_flows = [i['flowchart_sha256'] for i in json.loads(flow_map.read_text(encoding='utf-8'))['diagrams']]
    assert [hashlib.sha256(t.encode('utf-8')).hexdigest() for t in fences(new, 'flowchart')] == expected_flows
else:
    assert fences(baseline, 'flowchart') == fences(new, 'flowchart')
ids = re.findall(r':::page\{[^\n]*id="([^"]+)"', new)
if RESTRUCTURE.exists():
    revision = json.loads(RESTRUCTURE.read_text(encoding='utf-8'))
    expected = {p for p in revision['old_to_new'].values() if p} | set(revision['added_pages'])
    assert set(ids) == expected and len(ids) == revision['expected_containers']
else:
    assert re.findall(r':::page\{[^\n]*id="([^"]+)"', baseline) == ids
    assert len(ids) == 179
assert len(fences(new, 'python')) == len(code_specs) == 8
assert len(fences(new, 'flowchart')) == 4
assert not re.search(r'원본|\bPDF\b|원 교재|대조 수정판|코코봇|cocobot', new, re.I)
assert not re.search(r'\bAPI\b|인증키|지하철역', new, re.I), 'API activity must remain outside this course'
opening_positions = [new.index(f'id="ch{n:02d}-opening"') for n in range(1, 17)]
assert opening_positions == sorted(opening_positions)
assert 'Matplotlib 선 그래프와 마커' in chapters[11]
assert 'Matplotlib 막대그래프와 산점도' in chapters[12]
assert '입력 데이터를 차트로 표현하기' in chapters[13]
assert '자료 활용과 저장·불러오기' in chapters[14]
assert not re.search(r'pandas|DataFrame|Series|Divider|디바이더', new, re.I)
(BOOK / 'book.md').write_text(new, encoding='utf-8')
print(f'Learner manuscript assembled: {len(ids)} containers; retained code verified; diagram sources verified.')
